package com.example.stuacco_n_more_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
