import 'package:flutter/material.dart';
import '../../../core/config/theme_config.dart';

class QuantitySelector extends StatelessWidget {
  final int quantity;
  final Function(int) onQuantityChanged;
  final int maxQuantity;
  final int minQuantity;

  const QuantitySelector({
    super.key,
    required this.quantity,
    required this.onQuantityChanged,
    this.maxQuantity = 99,
    this.minQuantity = 1,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.grey[300]!),
        borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Decrease Button
          GestureDetector(
            onTap: quantity > minQuantity
                ? () => onQuantityChanged(quantity - 1)
                : null,
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: quantity > minQuantity
                    ? ThemeConfig.primaryColor.withOpacity(0.1)
                    : Colors.grey[100],
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(ThemeConfig.radiusM),
                  bottomLeft: Radius.circular(ThemeConfig.radiusM),
                ),
              ),
              child: Icon(
                Icons.remove,
                size: 20,
                color: quantity > minQuantity
                    ? ThemeConfig.primaryColor
                    : Colors.grey,
              ),
            ),
          ),
          
          // Quantity Display
          Container(
            width: 60,
            height: 40,
            decoration: const BoxDecoration(
              color: Colors.white,
            ),
            child: Center(
              child: Text(
                quantity.toString(),
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: ThemeConfig.textPrimary,
                ),
              ),
            ),
          ),
          
          // Increase Button
          GestureDetector(
            onTap: quantity < maxQuantity
                ? () => onQuantityChanged(quantity + 1)
                : null,
            child: Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: quantity < maxQuantity
                    ? ThemeConfig.primaryColor.withOpacity(0.1)
                    : Colors.grey[100],
                borderRadius: const BorderRadius.only(
                  topRight: Radius.circular(ThemeConfig.radiusM),
                  bottomRight: Radius.circular(ThemeConfig.radiusM),
                ),
              ),
              child: Icon(
                Icons.add,
                size: 20,
                color: quantity < maxQuantity
                    ? ThemeConfig.primaryColor
                    : Colors.grey,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
