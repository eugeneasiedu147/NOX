import 'package:flutter/material.dart';
import '../../../core/config/theme_config.dart';
import '../../../core/models/product_model.dart';

class CategoryTabs extends StatelessWidget {
  final ProductCategory? selectedCategory;
  final Function(ProductCategory?) onCategorySelected;

  const CategoryTabs({
    super.key,
    required this.selectedCategory,
    required this.onCategorySelected,
  });

  @override
  Widget build(BuildContext context) {
    final categories = [null, ...ProductCategory.values];
    
    return Container(
      height: 50,
      padding: const EdgeInsets.symmetric(vertical: ThemeConfig.spacingS),
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        padding: const EdgeInsets.symmetric(horizontal: ThemeConfig.spacingM),
        itemCount: categories.length,
        itemBuilder: (context, index) {
          final category = categories[index];
          final isSelected = selectedCategory == category;
          
          return GestureDetector(
            onTap: () => onCategorySelected(category),
            child: Container(
              margin: const EdgeInsets.only(right: ThemeConfig.spacingS),
              padding: const EdgeInsets.symmetric(
                horizontal: ThemeConfig.spacingM,
                vertical: ThemeConfig.spacingS,
              ),
              decoration: BoxDecoration(
                color: isSelected ? ThemeConfig.primaryColor : Colors.grey[200],
                borderRadius: BorderRadius.circular(ThemeConfig.radiusL),
              ),
              child: Text(
                category == null ? 'All' : _getCategoryDisplayName(category),
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: isSelected ? Colors.white : ThemeConfig.textSecondary,
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  String _getCategoryDisplayName(ProductCategory category) {
    switch (category) {
      case ProductCategory.furniture:
        return 'Furniture';
      case ProductCategory.kitchenware:
        return 'Kitchen';
      case ProductCategory.stationery:
        return 'Stationery';
      case ProductCategory.electronics:
        return 'Electronics';
      case ProductCategory.bedding:
        return 'Bedding';
      case ProductCategory.cleaning:
        return 'Cleaning';
      case ProductCategory.personalCare:
        return 'Personal Care';
      case ProductCategory.foodBeverages:
        return 'Food & Drinks';
      case ProductCategory.books:
        return 'Books';
      case ProductCategory.other:
        return 'Other';
    }
  }
}
