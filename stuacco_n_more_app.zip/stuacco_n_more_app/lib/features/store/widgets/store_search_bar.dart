import 'package:flutter/material.dart';
import '../../../core/config/theme_config.dart';

class StoreSearchBar extends StatefulWidget {
  final Function(String) onSearch;
  final String initialValue;

  const StoreSearchBar({
    super.key,
    required this.onSearch,
    this.initialValue = '',
  });

  @override
  State<StoreSearchBar> createState() => _StoreSearchBarState();
}

class _StoreSearchBarState extends State<StoreSearchBar> {
  late TextEditingController _controller;

  @override
  void initState() {
    super.initState();
    _controller = TextEditingController(text: widget.initialValue);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.grey[100],
        borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
      ),
      child: TextField(
        controller: _controller,
        onChanged: widget.onSearch,
        decoration: InputDecoration(
          hintText: 'Search products...',
          prefixIcon: const Icon(
            Icons.search,
            color: ThemeConfig.textSecondary,
          ),
          suffixIcon: _controller.text.isNotEmpty
              ? IconButton(
                  icon: const Icon(
                    Icons.clear,
                    color: ThemeConfig.textSecondary,
                  ),
                  onPressed: () {
                    _controller.clear();
                    widget.onSearch('');
                  },
                )
              : null,
          border: InputBorder.none,
          contentPadding: const EdgeInsets.symmetric(
            horizontal: ThemeConfig.spacingM,
            vertical: ThemeConfig.spacingM,
          ),
        ),
      ),
    );
  }
}
