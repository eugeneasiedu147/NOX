import 'package:flutter/material.dart';
import '../../../core/config/theme_config.dart';
import '../providers/store_provider.dart';
import 'quantity_selector.dart';

class CartItemCard extends StatelessWidget {
  final CartItem cartItem;
  final Function(int) onQuantityChanged;
  final VoidCallback onRemove;

  const CartItemCard({
    super.key,
    required this.cartItem,
    required this.onQuantityChanged,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.only(bottom: ThemeConfig.spacingM),
      padding: const EdgeInsets.all(ThemeConfig.spacingM),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(ThemeConfig.radiusL),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          // Product Image
          ClipRRect(
            borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
            child: Container(
              width: 80,
              height: 80,
              color: Colors.grey[300],
              child: cartItem.product.imageUrls.isNotEmpty
                  ? Image.network(
                      cartItem.product.imageUrls.first,
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) {
                        return const Icon(
                          Icons.shopping_bag,
                          size: 30,
                          color: Colors.grey,
                        );
                      },
                    )
                  : const Icon(
                      Icons.shopping_bag,
                      size: 30,
                      color: Colors.grey,
                    ),
            ),
          ),
          
          const SizedBox(width: ThemeConfig.spacingM),
          
          // Product Details
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  cartItem.product.name,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                    color: ThemeConfig.textPrimary,
                  ),
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                ),
                
                const SizedBox(height: ThemeConfig.spacingS),
                
                Row(
                  children: [
                    if (cartItem.product.discountPercentage != null && 
                        cartItem.product.discountPercentage! > 0) ...[
                      Text(
                        '₵${cartItem.product.price}',
                        style: const TextStyle(
                          fontSize: 14,
                          color: ThemeConfig.textSecondary,
                          decoration: TextDecoration.lineThrough,
                        ),
                      ),
                      const SizedBox(width: ThemeConfig.spacingS),
                    ],
                    Text(
                      '₵${cartItem.product.discountedPrice}',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: ThemeConfig.primaryColor,
                      ),
                    ),
                  ],
                ),
                
                const SizedBox(height: ThemeConfig.spacingM),
                
                // Quantity and Remove
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    QuantitySelector(
                      quantity: cartItem.quantity,
                      onQuantityChanged: onQuantityChanged,
                      maxQuantity: cartItem.product.stockQuantity,
                    ),
                    IconButton(
                      onPressed: onRemove,
                      icon: const Icon(
                        Icons.delete_outline,
                        color: ThemeConfig.errorColor,
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
