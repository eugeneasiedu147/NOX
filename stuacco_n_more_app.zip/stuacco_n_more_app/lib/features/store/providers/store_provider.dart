import 'package:flutter/material.dart';

import '../../../core/models/product_model.dart';
import '../../../core/services/firebase_service.dart';

class CartItem {
  final ProductModel product;
  int quantity;

  CartItem({
    required this.product,
    this.quantity = 1,
  });

  double get totalPrice => product.discountedPrice * quantity;
}

class StoreProvider extends ChangeNotifier {
  List<ProductModel> _products = [];
  List<ProductModel> _filteredProducts = [];
  List<CartItem> _cartItems = [];
  bool _isLoading = false;
  String? _errorMessage;
  
  // Filters
  String _searchQuery = '';
  ProductCategory? _selectedCategory;
  double _minPrice = 0;
  double _maxPrice = 1000;
  String _sortBy = 'name'; // name, price, rating

  List<ProductModel> get products => _filteredProducts;
  List<CartItem> get cartItems => _cartItems;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  String get searchQuery => _searchQuery;
  ProductCategory? get selectedCategory => _selectedCategory;
  double get minPrice => _minPrice;
  double get maxPrice => _maxPrice;
  String get sortBy => _sortBy;

  int get cartItemCount => _cartItems.fold(0, (sum, item) => sum + item.quantity);
  double get cartTotal => _cartItems.fold(0, (sum, item) => sum + item.totalPrice);

  Future<void> loadProducts() async {
    try {
      _setLoading(true);
      _clearError();

      final querySnapshot = await FirebaseService.products
          .where('isActive', isEqualTo: true)
          .orderBy('createdAt', descending: true)
          .get();

      _products = querySnapshot.docs
          .map((doc) => ProductModel.fromFirestore(doc))
          .toList();

      _applyFilters();
    } catch (e) {
      _setError('Failed to load products');
    } finally {
      _setLoading(false);
    }
  }

  Future<ProductModel?> getProductById(String id) async {
    try {
      final doc = await FirebaseService.products.doc(id).get();
      if (doc.exists) {
        return ProductModel.fromFirestore(doc);
      }
      return null;
    } catch (e) {
      print('Error getting product: $e');
      return null;
    }
  }

  void searchProducts(String query) {
    _searchQuery = query;
    _applyFilters();
  }

  void filterByCategory(ProductCategory? category) {
    _selectedCategory = category;
    _applyFilters();
  }

  void filterByPriceRange(double min, double max) {
    _minPrice = min;
    _maxPrice = max;
    _applyFilters();
  }

  void sortProducts(String sortBy) {
    _sortBy = sortBy;
    _applyFilters();
  }

  void clearFilters() {
    _searchQuery = '';
    _selectedCategory = null;
    _minPrice = 0;
    _maxPrice = 1000;
    _sortBy = 'name';
    _applyFilters();
  }

  void _applyFilters() {
    _filteredProducts = _products.where((product) {
      // Search filter
      if (_searchQuery.isNotEmpty) {
        final query = _searchQuery.toLowerCase();
        if (!product.name.toLowerCase().contains(query) &&
            !product.description.toLowerCase().contains(query)) {
          return false;
        }
      }

      // Category filter
      if (_selectedCategory != null && product.category != _selectedCategory) {
        return false;
      }

      // Price filter
      if (product.discountedPrice < _minPrice || product.discountedPrice > _maxPrice) {
        return false;
      }

      return true;
    }).toList();

    // Apply sorting
    _filteredProducts.sort((a, b) {
      switch (_sortBy) {
        case 'name':
          return a.name.compareTo(b.name);
        case 'price':
          return a.discountedPrice.compareTo(b.discountedPrice);
        case 'rating':
          return b.rating.compareTo(a.rating);
        default:
          return 0;
      }
    });

    notifyListeners();
  }

  void addToCart(ProductModel product, {int quantity = 1}) {
    final existingItemIndex = _cartItems.indexWhere(
      (item) => item.product.id == product.id,
    );

    if (existingItemIndex >= 0) {
      _cartItems[existingItemIndex].quantity += quantity;
    } else {
      _cartItems.add(CartItem(product: product, quantity: quantity));
    }

    notifyListeners();
  }

  void removeFromCart(String productId) {
    _cartItems.removeWhere((item) => item.product.id == productId);
    notifyListeners();
  }

  void updateCartItemQuantity(String productId, int quantity) {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }

    final itemIndex = _cartItems.indexWhere(
      (item) => item.product.id == productId,
    );

    if (itemIndex >= 0) {
      _cartItems[itemIndex].quantity = quantity;
      notifyListeners();
    }
  }

  void clearCart() {
    _cartItems.clear();
    notifyListeners();
  }

  bool isInCart(String productId) {
    return _cartItems.any((item) => item.product.id == productId);
  }

  int getCartItemQuantity(String productId) {
    final item = _cartItems.firstWhere(
      (item) => item.product.id == productId,
      orElse: () => CartItem(product: ProductModel(
        id: '',
        name: '',
        description: '',
        category: ProductCategory.other,
        price: 0,
        imageUrls: [],
        stockQuantity: 0,
        sellerId: '',
        specifications: {},
        tags: [],
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      )),
    );
    return item.product.id.isNotEmpty ? item.quantity : 0;
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String error) {
    _errorMessage = error;
    notifyListeners();
  }

  void _clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
