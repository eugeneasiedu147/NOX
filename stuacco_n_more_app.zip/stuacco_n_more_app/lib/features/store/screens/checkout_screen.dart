import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/config/theme_config.dart';
import '../providers/store_provider.dart';
import '../widgets/checkout_form.dart';

class CheckoutScreen extends StatelessWidget {
  const CheckoutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Checkout'),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      backgroundColor: ThemeConfig.backgroundColor,
      body: Consumer<StoreProvider>(
        builder: (context, provider, child) {
          if (provider.cartItems.isEmpty) {
            return const Center(
              child: Text('Your cart is empty'),
            );
          }

          return CheckoutForm(
            cartItems: provider.cartItems,
            total: provider.cartTotal,
            onOrderComplete: (orderId) {
              provider.clearCart();
              // Navigate to order confirmation
              Navigator.of(context).pushReplacementNamed('/order-confirmation/$orderId');
            },
          );
        },
      ),
    );
  }
}
