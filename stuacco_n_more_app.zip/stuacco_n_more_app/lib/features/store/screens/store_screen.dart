import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';

import '../../../core/config/theme_config.dart';
import '../../../core/models/product_model.dart';
import '../providers/store_provider.dart';
import '../widgets/product_card.dart';
import '../widgets/category_tabs.dart';
import '../widgets/store_search_bar.dart';

class StoreScreen extends StatefulWidget {
  const StoreScreen({super.key});

  @override
  State<StoreScreen> createState() => _StoreScreenState();
}

class _StoreScreenState extends State<StoreScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<StoreProvider>().loadProducts();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeConfig.backgroundColor,
      appBar: AppBar(
        title: const Text('Store'),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
          Consumer<StoreProvider>(
            builder: (context, provider, child) {
              return Stack(
                children: [
                  IconButton(
                    icon: const Icon(Icons.shopping_cart_outlined),
                    onPressed: () => context.push('/cart'),
                  ),
                  if (provider.cartItemCount > 0)
                    Positioned(
                      right: 8,
                      top: 8,
                      child: Container(
                        padding: const EdgeInsets.all(2),
                        decoration: BoxDecoration(
                          color: ThemeConfig.errorColor,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        constraints: const BoxConstraints(
                          minWidth: 16,
                          minHeight: 16,
                        ),
                        child: Text(
                          '${provider.cartItemCount}',
                          style: const TextStyle(
                            color: Colors.white,
                            fontSize: 12,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                    ),
                ],
              );
            },
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(ThemeConfig.spacingM),
            child: Consumer<StoreProvider>(
              builder: (context, provider, child) {
                return StoreSearchBar(
                  onSearch: provider.searchProducts,
                  initialValue: provider.searchQuery,
                );
              },
            ),
          ),
          
          // Category Tabs
          Container(
            color: Colors.white,
            child: Consumer<StoreProvider>(
              builder: (context, provider, child) {
                return CategoryTabs(
                  selectedCategory: provider.selectedCategory,
                  onCategorySelected: provider.filterByCategory,
                );
              },
            ),
          ),
          
          // Products Grid
          Expanded(
            child: Consumer<StoreProvider>(
              builder: (context, provider, child) {
                if (provider.isLoading) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (provider.errorMessage != null) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          provider.errorMessage!,
                          style: const TextStyle(color: ThemeConfig.errorColor),
                        ),
                        const SizedBox(height: ThemeConfig.spacingM),
                        ElevatedButton(
                          onPressed: () => provider.loadProducts(),
                          child: const Text('Retry'),
                        ),
                      ],
                    ),
                  );
                }

                if (provider.products.isEmpty) {
                  return const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.shopping_bag_outlined,
                          size: 64,
                          color: ThemeConfig.textHint,
                        ),
                        SizedBox(height: ThemeConfig.spacingM),
                        Text(
                          'No products found',
                          style: TextStyle(
                            fontSize: 18,
                            color: ThemeConfig.textSecondary,
                          ),
                        ),
                        SizedBox(height: ThemeConfig.spacingS),
                        Text(
                          'Try adjusting your search or filters',
                          style: TextStyle(
                            fontSize: 14,
                            color: ThemeConfig.textHint,
                          ),
                        ),
                      ],
                    ),
                  );
                }

                return RefreshIndicator(
                  onRefresh: provider.loadProducts,
                  child: GridView.builder(
                    padding: const EdgeInsets.all(ThemeConfig.spacingM),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2,
                      childAspectRatio: 0.75,
                      crossAxisSpacing: ThemeConfig.spacingM,
                      mainAxisSpacing: ThemeConfig.spacingM,
                    ),
                    itemCount: provider.products.length,
                    itemBuilder: (context, index) {
                      final product = provider.products[index];
                      return ProductCard(
                        product: product,
                        onTap: () => context.push('/product/${product.id}'),
                        onAddToCart: () => provider.addToCart(product),
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}
