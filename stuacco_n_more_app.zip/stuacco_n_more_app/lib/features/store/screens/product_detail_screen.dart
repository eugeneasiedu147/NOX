import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/config/theme_config.dart';
import '../../../core/models/product_model.dart';
import '../providers/store_provider.dart';
import '../widgets/product_image_gallery.dart';
import '../widgets/quantity_selector.dart';

class ProductDetailScreen extends StatefulWidget {
  final String productId;

  const ProductDetailScreen({
    super.key,
    required this.productId,
  });

  @override
  State<ProductDetailScreen> createState() => _ProductDetailScreenState();
}

class _ProductDetailScreenState extends State<ProductDetailScreen> {
  ProductModel? product;
  bool isLoading = true;
  int selectedQuantity = 1;

  @override
  void initState() {
    super.initState();
    _loadProduct();
  }

  Future<void> _loadProduct() async {
    // TODO: Load product from provider
    await Future.delayed(const Duration(seconds: 1));
    
    // Mock data for now
    setState(() {
      product = ProductModel(
        id: widget.productId,
        name: 'Student Desk Lamp',
        description: 'A modern LED desk lamp perfect for studying. Features adjustable brightness and color temperature.',
        category: ProductCategory.electronics,
        price: 120,
        imageUrls: [
          'https://via.placeholder.com/400x400',
          'https://via.placeholder.com/400x400',
          'https://via.placeholder.com/400x400',
        ],
        stockQuantity: 15,
        sellerId: 'seller123',
        specifications: {
          'Power': '12W',
          'Color Temperature': '3000K-6500K',
          'Material': 'Aluminum',
          'Warranty': '1 Year',
        },
        tags: ['LED', 'Adjustable', 'Study', 'Modern'],
        rating: 4.3,
        reviewCount: 47,
        discountPercentage: 10,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(),
      );
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (product == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Product')),
        body: const Center(
          child: Text('Product not found'),
        ),
      );
    }

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // App Bar with Images
          SliverAppBar(
            expandedHeight: 300,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: ProductImageGallery(
                imageUrls: product!.imageUrls,
              ),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.favorite_border),
                onPressed: () {
                  // TODO: Add to favorites
                },
              ),
              IconButton(
                icon: const Icon(Icons.share),
                onPressed: () {
                  // TODO: Share product
                },
              ),
            ],
          ),
          
          // Content
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(ThemeConfig.spacingL),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Name and Price
                  Text(
                    product!.name,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.bold,
                      color: ThemeConfig.textPrimary,
                    ),
                  ),
                  
                  const SizedBox(height: ThemeConfig.spacingS),
                  
                  // Price and Discount
                  Row(
                    children: [
                      if (product!.discountPercentage != null && product!.discountPercentage! > 0) ...[
                        Text(
                          '₵${product!.price}',
                          style: const TextStyle(
                            fontSize: 16,
                            color: ThemeConfig.textSecondary,
                            decoration: TextDecoration.lineThrough,
                          ),
                        ),
                        const SizedBox(width: ThemeConfig.spacingS),
                      ],
                      Text(
                        '₵${product!.discountedPrice}',
                        style: const TextStyle(
                          fontSize: 28,
                          fontWeight: FontWeight.bold,
                          color: ThemeConfig.primaryColor,
                        ),
                      ),
                      if (product!.discountPercentage != null && product!.discountPercentage! > 0) ...[
                        const SizedBox(width: ThemeConfig.spacingS),
                        Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: ThemeConfig.spacingS,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: ThemeConfig.errorColor,
                            borderRadius: BorderRadius.circular(ThemeConfig.radiusS),
                          ),
                          child: Text(
                            '${product!.discountPercentage!.round()}% OFF',
                            style: const TextStyle(
                              fontSize: 12,
                              fontWeight: FontWeight.bold,
                              color: Colors.white,
                            ),
                          ),
                        ),
                      ],
                    ],
                  ),
                  
                  const SizedBox(height: ThemeConfig.spacingM),
                  
                  // Rating and Stock
                  Row(
                    children: [
                      const Icon(
                        Icons.star,
                        size: 20,
                        color: Colors.amber,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        product!.rating.toString(),
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '(${product!.reviewCount} reviews)',
                        style: const TextStyle(
                          fontSize: 14,
                          color: ThemeConfig.textSecondary,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        '${product!.stockQuantity} in stock',
                        style: TextStyle(
                          fontSize: 14,
                          color: product!.stockQuantity > 0
                              ? ThemeConfig.successColor
                              : ThemeConfig.errorColor,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: ThemeConfig.spacingXL),
                  
                  // Description
                  const Text(
                    'Description',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: ThemeConfig.textPrimary,
                    ),
                  ),
                  const SizedBox(height: ThemeConfig.spacingM),
                  Text(
                    product!.description,
                    style: const TextStyle(
                      fontSize: 16,
                      color: ThemeConfig.textSecondary,
                      height: 1.5,
                    ),
                  ),
                  
                  const SizedBox(height: ThemeConfig.spacingXL),
                  
                  // Specifications
                  if (product!.specifications.isNotEmpty) ...[
                    const Text(
                      'Specifications',
                      style: TextStyle(
                        fontSize: 18,
                        fontWeight: FontWeight.bold,
                        color: ThemeConfig.textPrimary,
                      ),
                    ),
                    const SizedBox(height: ThemeConfig.spacingM),
                    Container(
                      decoration: BoxDecoration(
                        color: Colors.grey[50],
                        borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
                      ),
                      child: Column(
                        children: product!.specifications.entries.map((entry) {
                          return Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: ThemeConfig.spacingM,
                              vertical: ThemeConfig.spacingS,
                            ),
                            child: Row(
                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                              children: [
                                Text(
                                  entry.key,
                                  style: const TextStyle(
                                    fontSize: 14,
                                    color: ThemeConfig.textSecondary,
                                  ),
                                ),
                                Text(
                                  entry.value.toString(),
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                    color: ThemeConfig.textPrimary,
                                  ),
                                ),
                              ],
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ],
                  
                  const SizedBox(height: ThemeConfig.spacingXXL),
                ],
              ),
            ),
          ),
        ],
      ),
      
      // Bottom Bar
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(ThemeConfig.spacingL),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: Consumer<StoreProvider>(
          builder: (context, provider, child) {
            return Row(
              children: [
                // Quantity Selector
                QuantitySelector(
                  quantity: selectedQuantity,
                  onQuantityChanged: (quantity) {
                    setState(() {
                      selectedQuantity = quantity;
                    });
                  },
                  maxQuantity: product!.stockQuantity,
                ),
                
                const SizedBox(width: ThemeConfig.spacingM),
                
                // Add to Cart Button
                Expanded(
                  child: ElevatedButton(
                    onPressed: product!.isAvailable
                        ? () {
                            provider.addToCart(product!, quantity: selectedQuantity);
                            ScaffoldMessenger.of(context).showSnackBar(
                              const SnackBar(
                                content: Text('Added to cart'),
                                duration: Duration(seconds: 2),
                              ),
                            );
                          }
                        : null,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: ThemeConfig.primaryColor,
                      foregroundColor: Colors.white,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
                      ),
                      padding: const EdgeInsets.symmetric(vertical: ThemeConfig.spacingM),
                    ),
                    child: Text(
                      product!.isAvailable ? 'Add to Cart' : 'Out of Stock',
                      style: const TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }
}
