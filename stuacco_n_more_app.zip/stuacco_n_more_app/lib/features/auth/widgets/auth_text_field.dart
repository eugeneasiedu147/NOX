import 'package:flutter/material.dart';
import '../../../core/config/theme_config.dart';

class AuthTextField extends StatelessWidget {
  final TextEditingController controller;
  final String label;
  final String hintText;
  final bool obscureText;
  final TextInputType keyboardType;
  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final String? Function(String?)? validator;
  final void Function(String)? onChanged;
  final int maxLines;
  final bool enabled;

  const AuthTextField({
    super.key,
    required this.controller,
    required this.label,
    required this.hintText,
    this.obscureText = false,
    this.keyboardType = TextInputType.text,
    this.prefixIcon,
    this.suffixIcon,
    this.validator,
    this.onChanged,
    this.maxLines = 1,
    this.enabled = true,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: ThemeConfig.bodyM.copyWith(
            fontWeight: FontWeight.w500,
            color: ThemeConfig.textPrimary,
          ),
        ),
        const SizedBox(height: ThemeConfig.spacingS),
        TextFormField(
          controller: controller,
          obscureText: obscureText,
          keyboardType: keyboardType,
          validator: validator,
          onChanged: onChanged,
          maxLines: maxLines,
          enabled: enabled,
          style: ThemeConfig.bodyM,
          decoration: InputDecoration(
            hintText: hintText,
            prefixIcon: prefixIcon,
            suffixIcon: suffixIcon,
            filled: true,
            fillColor: enabled ? Colors.grey[50] : Colors.grey[100],
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
              borderSide: const BorderSide(color: ThemeConfig.borderColor),
            ),
            enabledBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
              borderSide: const BorderSide(color: ThemeConfig.borderColor),
            ),
            focusedBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
              borderSide: const BorderSide(
                color: ThemeConfig.primaryColor,
                width: 2,
              ),
            ),
            errorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
              borderSide: const BorderSide(color: ThemeConfig.errorColor),
            ),
            focusedErrorBorder: OutlineInputBorder(
              borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
              borderSide: const BorderSide(
                color: ThemeConfig.errorColor,
                width: 2,
              ),
            ),
            contentPadding: const EdgeInsets.symmetric(
              horizontal: ThemeConfig.spacingL,
              vertical: ThemeConfig.spacingM,
            ),
            hintStyle: ThemeConfig.bodyM.copyWith(
              color: ThemeConfig.textHint,
            ),
          ),
        ),
      ],
    );
  }
}
