import 'package:flutter/material.dart';
import '../../../core/config/theme_config.dart';

class AuthButton extends StatelessWidget {
  final String text;
  final VoidCallback? onPressed;
  final bool isLoading;
  final bool isOutlined;
  final Color? backgroundColor;
  final Color? textColor;
  final Widget? icon;

  const AuthButton({
    super.key,
    required this.text,
    this.onPressed,
    this.isLoading = false,
    this.isOutlined = false,
    this.backgroundColor,
    this.textColor,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    if (isOutlined) {
      return OutlinedButton(
        onPressed: isLoading ? null : onPressed,
        style: OutlinedButton.styleFrom(
          foregroundColor: textColor ?? ThemeConfig.primaryColor,
          side: BorderSide(
            color: backgroundColor ?? ThemeConfig.primaryColor,
          ),
          padding: const EdgeInsets.symmetric(
            horizontal: ThemeConfig.spacingXL,
            vertical: ThemeConfig.spacingL,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
          ),
        ),
        child: SizedBox(
          height: 24,
          child: isLoading
              ? const SizedBox(
                  width: 20,
                  height: 20,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(
                      ThemeConfig.primaryColor,
                    ),
                  ),
                )
              : Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (icon != null) ...[
                      icon!,
                      const SizedBox(width: ThemeConfig.spacingS),
                    ],
                    Text(
                      text,
                      style: ThemeConfig.buttonText.copyWith(
                        color: textColor ?? ThemeConfig.primaryColor,
                      ),
                    ),
                  ],
                ),
        ),
      );
    }

    return ElevatedButton(
      onPressed: isLoading ? null : onPressed,
      style: ElevatedButton.styleFrom(
        backgroundColor: backgroundColor ?? ThemeConfig.primaryColor,
        foregroundColor: textColor ?? Colors.white,
        elevation: ThemeConfig.elevationS,
        padding: const EdgeInsets.symmetric(
          horizontal: ThemeConfig.spacingXL,
          vertical: ThemeConfig.spacingL,
        ),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
        ),
      ),
      child: SizedBox(
        height: 24,
        child: isLoading
            ? const SizedBox(
                width: 20,
                height: 20,
                child: CircularProgressIndicator(
                  strokeWidth: 2,
                  valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                ),
              )
            : Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (icon != null) ...[
                    icon!,
                    const SizedBox(width: ThemeConfig.spacingS),
                  ],
                  Text(
                    text,
                    style: ThemeConfig.buttonText.copyWith(
                      color: textColor ?? Colors.white,
                    ),
                  ),
                ],
              ),
      ),
    );
  }
}
