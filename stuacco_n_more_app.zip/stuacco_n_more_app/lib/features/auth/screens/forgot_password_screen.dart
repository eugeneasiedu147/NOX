import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';

import '../../../core/config/theme_config.dart';
import '../providers/auth_provider.dart';
import '../widgets/auth_text_field.dart';
import '../widgets/auth_button.dart';

class ForgotPasswordScreen extends StatefulWidget {
  const ForgotPasswordScreen({super.key});

  @override
  State<ForgotPasswordScreen> createState() => _ForgotPasswordScreenState();
}

class _ForgotPasswordScreenState extends State<ForgotPasswordScreen> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  bool _emailSent = false;

  @override
  void dispose() {
    _emailController.dispose();
    super.dispose();
  }

  Future<void> _handleResetPassword() async {
    if (!_formKey.currentState!.validate()) return;

    final authProvider = context.read<AuthProvider>();
    final success = await authProvider.resetPassword(_emailController.text.trim());

    if (success) {
      setState(() {
        _emailSent = true;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeConfig.backgroundColor,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => context.pop(),
        ),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(ThemeConfig.spacingL),
          child: _emailSent ? _buildSuccessView() : _buildFormView(),
        ),
      ),
    );
  }

  Widget _buildFormView() {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          const SizedBox(height: ThemeConfig.spacingXXL),
          
          // Icon
          Center(
            child: Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: ThemeConfig.primaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(ThemeConfig.radiusXL),
              ),
              child: const Icon(
                Icons.lock_reset,
                size: 40,
                color: ThemeConfig.primaryColor,
              ),
            ),
          ),
          
          const SizedBox(height: ThemeConfig.spacingXL),
          
          // Title and Description
          const Text(
            'Reset Password',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: ThemeConfig.primaryColor,
            ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: ThemeConfig.spacingM),
          const Text(
            'Enter your email address and we\'ll send you a link to reset your password.',
            style: TextStyle(
              fontSize: 16,
              color: ThemeConfig.textSecondary,
            ),
            textAlign: TextAlign.center,
          ),
          
          const SizedBox(height: ThemeConfig.spacingXXL),
          
          // Email Field
          AuthTextField(
            controller: _emailController,
            label: 'Email Address',
            keyboardType: TextInputType.emailAddress,
            prefixIcon: const Icon(Icons.email_outlined),
            validator: (value) {
              if (value == null || value.isEmpty) {
                return 'Please enter your email';
              }
              if (!RegExp(r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$').hasMatch(value)) {
                return 'Please enter a valid email';
              }
              return null;
            }, hintText: '',
          ),
          
          const SizedBox(height: ThemeConfig.spacingXL),
          
          // Reset Button
          Consumer<AuthProvider>(
            builder: (context, authProvider, child) {
              return AuthButton(
                text: 'Send Reset Link',
                onPressed: _handleResetPassword,
                isLoading: authProvider.isLoading,
              );
            },
          ),
          
          // Error Message
          Consumer<AuthProvider>(
            builder: (context, authProvider, child) {
              if (authProvider.errorMessage != null) {
                return Padding(
                  padding: const EdgeInsets.only(top: ThemeConfig.spacingM),
                  child: Text(
                    authProvider.errorMessage!,
                    style: const TextStyle(
                      color: ThemeConfig.errorColor,
                      fontSize: 14,
                    ),
                    textAlign: TextAlign.center,
                  ),
                );
              }
              return const SizedBox.shrink();
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSuccessView() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SizedBox(height: ThemeConfig.spacingXXL),
        
        // Success Icon
        Center(
          child: Container(
            width: 80,
            height: 80,
            decoration: BoxDecoration(
              color: ThemeConfig.successColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(ThemeConfig.radiusXL),
            ),
            child: const Icon(
              Icons.check_circle,
              size: 40,
              color: ThemeConfig.successColor,
            ),
          ),
        ),
        
        const SizedBox(height: ThemeConfig.spacingXL),
        
        // Success Message
        const Text(
          'Email Sent!',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
            color: ThemeConfig.successColor,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: ThemeConfig.spacingM),
        Text(
          'We\'ve sent a password reset link to ${_emailController.text}',
          style: const TextStyle(
            fontSize: 16,
            color: ThemeConfig.textSecondary,
          ),
          textAlign: TextAlign.center,
        ),
        
        const SizedBox(height: ThemeConfig.spacingXXL),
        
        // Back to Login Button
        AuthButton(
          text: 'Back to Login',
          onPressed: () => context.go('/login'),
        ),
      ],
    );
  }
}
