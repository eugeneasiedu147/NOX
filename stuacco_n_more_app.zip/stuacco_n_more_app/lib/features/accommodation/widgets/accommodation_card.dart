import 'package:flutter/material.dart';
import '../../../core/config/theme_config.dart';
import '../../../core/models/accommodation_model.dart';

class AccommodationCard extends StatelessWidget {
  final AccommodationModel accommodation;
  final VoidCallback onTap;

  const AccommodationCard({
    super.key,
    required this.accommodation,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.only(bottom: ThemeConfig.spacingM),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(ThemeConfig.radiusL),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Image
            ClipRRect(
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(ThemeConfig.radiusL),
              ),
              child: Stack(
                children: [
                  Container(
                    height: 200,
                    width: double.infinity,
                    color: Colors.grey[300],
                    child: accommodation.imageUrls.isNotEmpty
                        ? Image.network(
                            accommodation.imageUrls.first,
                            fit: BoxFit.cover,
                            errorBuilder: (context, error, stackTrace) {
                              return const Icon(
                                Icons.home,
                                size: 60,
                                color: Colors.grey,
                              );
                            },
                          )
                        : const Icon(
                            Icons.home,
                            size: 60,
                            color: Colors.grey,
                          ),
                  ),
                  
                  // Status Badge
                  Positioned(
                    top: ThemeConfig.spacingM,
                    left: ThemeConfig.spacingM,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: ThemeConfig.spacingS,
                        vertical: ThemeConfig.spacingXS,
                      ),
                      decoration: BoxDecoration(
                        color: accommodation.isAvailable
                            ? ThemeConfig.successColor
                            : ThemeConfig.errorColor,
                        borderRadius: BorderRadius.circular(ThemeConfig.radiusS),
                      ),
                      child: Text(
                        accommodation.isAvailable ? 'Available' : 'Occupied',
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ),
                  
                  // Favorite Button
                  Positioned(
                    top: ThemeConfig.spacingM,
                    right: ThemeConfig.spacingM,
                    child: Container(
                      width: 36,
                      height: 36,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(18),
                      ),
                      child: const Icon(
                        Icons.favorite_border,
                        size: 20,
                        color: ThemeConfig.textSecondary,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            // Content
            Padding(
              padding: const EdgeInsets.all(ThemeConfig.spacingM),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title and Type
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          accommodation.title,
                          style: const TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                            color: ThemeConfig.textPrimary,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      Container(
                        padding: const EdgeInsets.symmetric(
                          horizontal: ThemeConfig.spacingS,
                          vertical: ThemeConfig.spacingXS,
                        ),
                        decoration: BoxDecoration(
                          color: ThemeConfig.primaryColor.withOpacity(0.1),
                          borderRadius: BorderRadius.circular(ThemeConfig.radiusS),
                        ),
                        child: Text(
                          accommodation.type.name.toUpperCase(),
                          style: const TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                            color: ThemeConfig.primaryColor,
                          ),
                        ),
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: ThemeConfig.spacingS),
                  
                  // Location
                  Row(
                    children: [
                      const Icon(
                        Icons.location_on,
                        size: 16,
                        color: ThemeConfig.textSecondary,
                      ),
                      const SizedBox(width: 4),
                      Expanded(
                        child: Text(
                          accommodation.address,
                          style: const TextStyle(
                            fontSize: 14,
                            color: ThemeConfig.textSecondary,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: ThemeConfig.spacingM),
                  
                  // Amenities Preview
                  if (accommodation.amenities.isNotEmpty)
                    Wrap(
                      spacing: ThemeConfig.spacingS,
                      children: accommodation.amenities.take(3).map((amenity) {
                        return Container(
                          padding: const EdgeInsets.symmetric(
                            horizontal: ThemeConfig.spacingS,
                            vertical: 2,
                          ),
                          decoration: BoxDecoration(
                            color: Colors.grey[100],
                            borderRadius: BorderRadius.circular(ThemeConfig.radiusS),
                          ),
                          child: Text(
                            amenity,
                            style: const TextStyle(
                              fontSize: 12,
                              color: ThemeConfig.textSecondary,
                            ),
                          ),
                        );
                      }).toList(),
                    ),
                  
                  const SizedBox(height: ThemeConfig.spacingM),
                  
                  // Price and Rating
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            '₵${accommodation.price}',
                            style: const TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.bold,
                              color: ThemeConfig.primaryColor,
                            ),
                          ),
                          const Text(
                            'per month',
                            style: TextStyle(
                              fontSize: 12,
                              color: ThemeConfig.textSecondary,
                            ),
                          ),
                        ],
                      ),
                      Row(
                        children: [
                          const Icon(
                            Icons.star,
                            size: 16,
                            color: Colors.amber,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            accommodation.rating.toString(),
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                          const SizedBox(width: 4),
                          Text(
                            '(${accommodation.reviewCount})',
                            style: const TextStyle(
                              fontSize: 12,
                              color: ThemeConfig.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
