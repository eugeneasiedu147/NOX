import 'package:flutter/material.dart';
import '../../../core/config/theme_config.dart';

class AmenitiesList extends StatelessWidget {
  final List<String> amenities;

  const AmenitiesList({
    super.key,
    required this.amenities,
  });

  @override
  Widget build(BuildContext context) {
    if (amenities.isEmpty) {
      return const Text(
        'No amenities listed',
        style: TextStyle(
          color: ThemeConfig.textSecondary,
          fontStyle: FontStyle.italic,
        ),
      );
    }

    return Wrap(
      spacing: ThemeConfig.spacingS,
      runSpacing: ThemeConfig.spacingS,
      children: amenities.map((amenity) {
        return Container(
          padding: const EdgeInsets.symmetric(
            horizontal: ThemeConfig.spacingM,
            vertical: ThemeConfig.spacingS,
          ),
          decoration: BoxDecoration(
            color: ThemeConfig.primaryColor.withOpacity(0.1),
            borderRadius: BorderRadius.circular(ThemeConfig.radiusL),
            border: Border.all(
              color: ThemeConfig.primaryColor.withOpacity(0.3),
            ),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                _getAmenityIcon(amenity),
                size: 16,
                color: ThemeConfig.primaryColor,
              ),
              const SizedBox(width: ThemeConfig.spacingS),
              Text(
                amenity,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w500,
                  color: ThemeConfig.primaryColor,
                ),
              ),
            ],
          ),
        );
      }).toList(),
    );
  }

  IconData _getAmenityIcon(String amenity) {
    switch (amenity.toLowerCase()) {
      case 'wifi':
        return Icons.wifi;
      case 'air conditioning':
        return Icons.ac_unit;
      case 'kitchen':
        return Icons.kitchen;
      case 'laundry':
        return Icons.local_laundry_service;
      case 'security':
        return Icons.security;
      case 'parking':
        return Icons.local_parking;
      case 'gym':
        return Icons.fitness_center;
      case 'study room':
        return Icons.menu_book;
      case 'common area':
        return Icons.people;
      case 'balcony':
        return Icons.balcony;
      default:
        return Icons.check_circle;
    }
  }
}
