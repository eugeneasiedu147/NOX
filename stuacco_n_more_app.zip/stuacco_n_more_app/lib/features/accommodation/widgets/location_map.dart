import 'package:flutter/material.dart';
import '../../../core/config/theme_config.dart';

class LocationMap extends StatelessWidget {
  final double latitude;
  final double longitude;
  final String address;

  const LocationMap({
    super.key,
    required this.latitude,
    required this.longitude,
    required this.address,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 200,
      decoration: BoxDecoration(
        color: Colors.grey[300],
        borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
      ),
      child: Stack(
        children: [
          // Placeholder for Google Maps
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(
                  Icons.map,
                  size: 60,
                  color: Colors.grey,
                ),
                const SizedBox(height: ThemeConfig.spacingS),
                Text(
                  'Map View',
                  style: TextStyle(
                    fontSize: 16,
                    color: Colors.grey[600],
                  ),
                ),
                const SizedBox(height: ThemeConfig.spacingS),
                Text(
                  address,
                  style: const TextStyle(
                    fontSize: 12,
                    color: ThemeConfig.textSecondary,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          
          // Get Directions Button
          Positioned(
            bottom: ThemeConfig.spacingM,
            right: ThemeConfig.spacingM,
            child: FloatingActionButton.small(
              onPressed: () {
                // TODO: Open directions in maps app
              },
              backgroundColor: ThemeConfig.primaryColor,
              child: const Icon(
                Icons.directions,
                color: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
