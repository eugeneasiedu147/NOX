import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../../core/config/theme_config.dart';
import '../../../core/models/accommodation_model.dart';
import '../providers/accommodation_provider.dart';

class AccommodationFilters extends StatefulWidget {
  const AccommodationFilters({super.key});

  @override
  State<AccommodationFilters> createState() => _AccommodationFiltersState();
}

class _AccommodationFiltersState extends State<AccommodationFilters> {
  late AccommodationType? _selectedType;
  late RangeValues _priceRange;
  late List<String> _selectedAmenities;
  late String _sortBy;

  final List<String> _availableAmenities = [
    'WiFi',
    'Air Conditioning',
    'Kitchen',
    'Laundry',
    'Security',
    'Parking',
    'Gym',
    'Study Room',
    'Common Area',
    'Balcony',
  ];

  @override
  void initState() {
    super.initState();
    final provider = context.read<AccommodationProvider>();
    _selectedType = provider.selectedType;
    _priceRange = RangeValues(provider.minPrice, provider.maxPrice);
    _selectedAmenities = List.from(provider.selectedAmenities);
    _sortBy = provider.sortBy;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: MediaQuery.of(context).size.height * 0.8,
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(
          top: Radius.circular(ThemeConfig.radiusXL),
        ),
      ),
      child: Column(
        children: [
          // Handle
          Container(
            width: 40,
            height: 4,
            margin: const EdgeInsets.symmetric(vertical: ThemeConfig.spacingM),
            decoration: BoxDecoration(
              color: Colors.grey[300],
              borderRadius: BorderRadius.circular(2),
            ),
          ),
          
          // Header
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: ThemeConfig.spacingL),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Filters',
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                TextButton(
                  onPressed: _clearFilters,
                  child: const Text('Clear All'),
                ),
              ],
            ),
          ),
          
          const Divider(),
          
          // Filters Content
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(ThemeConfig.spacingL),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Accommodation Type
                  _buildSectionTitle('Accommodation Type'),
                  const SizedBox(height: ThemeConfig.spacingM),
                  Wrap(
                    spacing: ThemeConfig.spacingS,
                    children: AccommodationType.values.map((type) {
                      return FilterChip(
                        label: Text(type.name.toUpperCase()),
                        selected: _selectedType == type,
                        onSelected: (selected) {
                          setState(() {
                            _selectedType = selected ? type : null;
                          });
                        },
                      );
                    }).toList(),
                  ),
                  
                  const SizedBox(height: ThemeConfig.spacingXL),
                  
                  // Price Range
                  _buildSectionTitle('Price Range (₵)'),
                  const SizedBox(height: ThemeConfig.spacingM),
                  RangeSlider(
                    values: _priceRange,
                    min: 0,
                    max: 5000,
                    divisions: 50,
                    labels: RangeLabels(
                      '₵${_priceRange.start.round()}',
                      '₵${_priceRange.end.round()}',
                    ),
                    onChanged: (values) {
                      setState(() {
                        _priceRange = values;
                      });
                    },
                  ),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text('₵${_priceRange.start.round()}'),
                      Text('₵${_priceRange.end.round()}'),
                    ],
                  ),
                  
                  const SizedBox(height: ThemeConfig.spacingXL),
                  
                  // Amenities
                  _buildSectionTitle('Amenities'),
                  const SizedBox(height: ThemeConfig.spacingM),
                  Wrap(
                    spacing: ThemeConfig.spacingS,
                    runSpacing: ThemeConfig.spacingS,
                    children: _availableAmenities.map((amenity) {
                      return FilterChip(
                        label: Text(amenity),
                        selected: _selectedAmenities.contains(amenity),
                        onSelected: (selected) {
                          setState(() {
                            if (selected) {
                              _selectedAmenities.add(amenity);
                            } else {
                              _selectedAmenities.remove(amenity);
                            }
                          });
                        },
                      );
                    }).toList(),
                  ),
                  
                  const SizedBox(height: ThemeConfig.spacingXL),
                  
                  // Sort By
                  _buildSectionTitle('Sort By'),
                  const SizedBox(height: ThemeConfig.spacingM),
                  Column(
                    children: [
                      RadioListTile<String>(
                        title: const Text('Price (Low to High)'),
                        value: 'price',
                        groupValue: _sortBy,
                        onChanged: (value) {
                          setState(() {
                            _sortBy = value!;
                          });
                        },
                      ),
                      RadioListTile<String>(
                        title: const Text('Rating (High to Low)'),
                        value: 'rating',
                        groupValue: _sortBy,
                        onChanged: (value) {
                          setState(() {
                            _sortBy = value!;
                          });
                        },
                      ),
                      RadioListTile<String>(
                        title: const Text('Distance'),
                        value: 'distance',
                        groupValue: _sortBy,
                        onChanged: (value) {
                          setState(() {
                            _sortBy = value!;
                          });
                        },
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          
          // Apply Button
          Padding(
            padding: const EdgeInsets.all(ThemeConfig.spacingL),
            child: SizedBox(
              width: double.infinity,
              height: 56,
              child: ElevatedButton(
                onPressed: _applyFilters,
                style: ElevatedButton.styleFrom(
                  backgroundColor: ThemeConfig.primaryColor,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
                  ),
                ),
                child: const Text(
                  'Apply Filters',
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(
      title,
      style: const TextStyle(
        fontSize: 16,
        fontWeight: FontWeight.w600,
        color: ThemeConfig.textPrimary,
      ),
    );
  }

  void _clearFilters() {
    setState(() {
      _selectedType = null;
      _priceRange = const RangeValues(0, 5000);
      _selectedAmenities.clear();
      _sortBy = 'price';
    });
  }

  void _applyFilters() {
    final provider = context.read<AccommodationProvider>();
    provider.filterByType(_selectedType);
    provider.filterByPriceRange(_priceRange.start, _priceRange.end);
    provider.filterByAmenities(_selectedAmenities);
    provider.sortAccommodations(_sortBy);
    Navigator.of(context).pop();
  }
}
