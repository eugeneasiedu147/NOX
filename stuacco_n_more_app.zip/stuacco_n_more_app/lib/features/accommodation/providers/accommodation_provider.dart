import 'package:flutter/material.dart';

import '../../../core/models/accommodation_model.dart';
import '../../../core/services/firebase_service.dart';

class AccommodationProvider extends ChangeNotifier {
  List<AccommodationModel> _accommodations = [];
  List<AccommodationModel> _filteredAccommodations = [];
  bool _isLoading = false;
  String? _errorMessage;
  
  // Filters
  String _searchQuery = '';
  AccommodationType? _selectedType;
  double _minPrice = 0;
  double _maxPrice = 5000;
  List<String> _selectedAmenities = [];
  String _sortBy = 'price'; // price, rating, distance

  List<AccommodationModel> get accommodations => _filteredAccommodations;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;
  String get searchQuery => _searchQuery;
  AccommodationType? get selectedType => _selectedType;
  double get minPrice => _minPrice;
  double get maxPrice => _maxPrice;
  List<String> get selectedAmenities => _selectedAmenities;
  String get sortBy => _sortBy;

  Future<void> loadAccommodations() async {
    try {
      _setLoading(true);
      _clearError();

      final querySnapshot = await FirebaseService.accommodations
          .where('isActive', isEqualTo: true)
          .orderBy('createdAt', descending: true)
          .get();

      _accommodations = querySnapshot.docs
          .map((doc) => AccommodationModel.fromFirestore(doc))
          .toList();

      _applyFilters();
    } catch (e) {
      _setError('Failed to load accommodations');
    } finally {
      _setLoading(false);
    }
  }

  Future<AccommodationModel?> getAccommodationById(String id) async {
    try {
      final doc = await FirebaseService.accommodations.doc(id).get();
      if (doc.exists) {
        return AccommodationModel.fromFirestore(doc);
      }
      return null;
    } catch (e) {
      print('Error getting accommodation: $e');
      return null;
    }
  }

  void searchAccommodations(String query) {
    _searchQuery = query;
    _applyFilters();
  }

  void filterByType(AccommodationType? type) {
    _selectedType = type;
    _applyFilters();
  }

  void filterByPriceRange(double min, double max) {
    _minPrice = min;
    _maxPrice = max;
    _applyFilters();
  }

  void filterByAmenities(List<String> amenities) {
    _selectedAmenities = amenities;
    _applyFilters();
  }

  void sortAccommodations(String sortBy) {
    _sortBy = sortBy;
    _applyFilters();
  }

  void clearFilters() {
    _searchQuery = '';
    _selectedType = null;
    _minPrice = 0;
    _maxPrice = 5000;
    _selectedAmenities = [];
    _sortBy = 'price';
    _applyFilters();
  }

  void _applyFilters() {
    _filteredAccommodations = _accommodations.where((accommodation) {
      // Search filter
      if (_searchQuery.isNotEmpty) {
        final query = _searchQuery.toLowerCase();
        if (!accommodation.title.toLowerCase().contains(query) &&
            !accommodation.address.toLowerCase().contains(query)) {
          return false;
        }
      }

      // Type filter
      if (_selectedType != null && accommodation.type != _selectedType) {
        return false;
      }

      // Price filter
      if (accommodation.price < _minPrice || accommodation.price > _maxPrice) {
        return false;
      }

      // Amenities filter
      if (_selectedAmenities.isNotEmpty) {
        final hasAllAmenities = _selectedAmenities.every(
          (amenity) => accommodation.amenities.contains(amenity),
        );
        if (!hasAllAmenities) {
          return false;
        }
      }

      return true;
    }).toList();

    // Apply sorting
    _filteredAccommodations.sort((a, b) {
      switch (_sortBy) {
        case 'price':
          return a.price.compareTo(b.price);
        case 'rating':
          return b.rating.compareTo(a.rating);
        case 'distance':
          // TODO: Implement distance sorting based on user location
          return 0;
        default:
          return 0;
      }
    });

    notifyListeners();
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String error) {
    _errorMessage = error;
    notifyListeners();
  }

  void _clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
