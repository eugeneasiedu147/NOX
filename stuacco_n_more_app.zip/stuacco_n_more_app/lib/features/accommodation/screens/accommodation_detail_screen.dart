import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/config/theme_config.dart';
import '../../../core/models/accommodation_model.dart';
import '../widgets/image_gallery.dart';
import '../widgets/amenities_list.dart';
import '../widgets/location_map.dart';

class AccommodationDetailScreen extends StatefulWidget {
  final String accommodationId;

  const AccommodationDetailScreen({
    super.key,
    required this.accommodationId,
  });

  @override
  State<AccommodationDetailScreen> createState() => _AccommodationDetailScreenState();
}

class _AccommodationDetailScreenState extends State<AccommodationDetailScreen> {
  AccommodationModel? accommodation;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadAccommodation();
  }

  Future<void> _loadAccommodation() async {
    // TODO: Load accommodation from provider
    await Future.delayed(const Duration(seconds: 1));
    
    // Mock data for now
    setState(() {
      accommodation = AccommodationModel(
        id: widget.accommodationId,
        title: 'Modern Student Hostel',
        description: 'A comfortable and modern hostel perfect for students. Located near the university campus with all necessary amenities.',
        type: AccommodationType.hostel,
        price: 800,
        address: '123 University Avenue, Accra',
        latitude: 5.6037,
        longitude: -0.1870,
        landlordId: 'landlord123',
        imageUrls: [
          'https://via.placeholder.com/400x300',
          'https://via.placeholder.com/400x300',
          'https://via.placeholder.com/400x300',
        ],
        amenities: ['WiFi', 'Air Conditioning', 'Kitchen', 'Laundry', 'Security'],
        maxOccupants: 2,
        status: AccommodationStatus.available,
        availableFrom: DateTime.now(),
        rules: {
          'no_smoking': true,
          'no_pets': true,
          'quiet_hours': '10 PM - 6 AM',
        },
        rating: 4.5,
        reviewCount: 23,
        createdAt: DateTime.now(),
        updatedAt: DateTime.now(), name: '', location: {}, specifications: {}, capacity: 2, availableSpaces: 2, tags: [], contact: {},
      );
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (accommodation == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Accommodation')),
        body: const Center(
          child: Text('Accommodation not found'),
        ),
      );
    }

    return Scaffold(
      body: CustomScrollView(
        slivers: [
          // App Bar with Images
          SliverAppBar(
            expandedHeight: 300,
            pinned: true,
            flexibleSpace: FlexibleSpaceBar(
              background: ImageGallery(
                imageUrls: accommodation!.imageUrls,
              ),
            ),
            actions: [
              IconButton(
                icon: const Icon(Icons.favorite_border),
                onPressed: () {
                  // TODO: Add to favorites
                },
              ),
              IconButton(
                icon: const Icon(Icons.share),
                onPressed: () {
                  // TODO: Share accommodation
                },
              ),
            ],
          ),
          
          // Content
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(ThemeConfig.spacingL),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Title and Price
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              accommodation!.title,
                              style: const TextStyle(
                                fontSize: 24,
                                fontWeight: FontWeight.bold,
                                color: ThemeConfig.textPrimary,
                              ),
                            ),
                            const SizedBox(height: ThemeConfig.spacingS),
                            Row(
                              children: [
                                const Icon(
                                  Icons.location_on,
                                  size: 16,
                                  color: ThemeConfig.textSecondary,
                                ),
                                const SizedBox(width: 4),
                                Expanded(
                                  child: Text(
                                    accommodation!.address,
                                    style: const TextStyle(
                                      fontSize: 14,
                                      color: ThemeConfig.textSecondary,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                      ),
                      Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            '₵${accommodation!.price}',
                            style: const TextStyle(
                              fontSize: 28,
                              fontWeight: FontWeight.bold,
                              color: ThemeConfig.primaryColor,
                            ),
                          ),
                          const Text(
                            'per month',
                            style: TextStyle(
                              fontSize: 14,
                              color: ThemeConfig.textSecondary,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: ThemeConfig.spacingM),
                  
                  // Rating and Reviews
                  Row(
                    children: [
                      const Icon(
                        Icons.star,
                        size: 20,
                        color: Colors.amber,
                      ),
                      const SizedBox(width: 4),
                      Text(
                        accommodation!.rating.toString(),
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '(${accommodation!.reviewCount} reviews)',
                        style: const TextStyle(
                          fontSize: 14,
                          color: ThemeConfig.textSecondary,
                        ),
                      ),
                    ],
                  ),
                  
                  const SizedBox(height: ThemeConfig.spacingXL),
                  
                  // Description
                  const Text(
                    'Description',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: ThemeConfig.textPrimary,
                    ),
                  ),
                  const SizedBox(height: ThemeConfig.spacingM),
                  Text(
                    accommodation!.description,
                    style: const TextStyle(
                      fontSize: 16,
                      color: ThemeConfig.textSecondary,
                      height: 1.5,
                    ),
                  ),
                  
                  const SizedBox(height: ThemeConfig.spacingXL),
                  
                  // Amenities
                  const Text(
                    'Amenities',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: ThemeConfig.textPrimary,
                    ),
                  ),
                  const SizedBox(height: ThemeConfig.spacingM),
                  AmenitiesList(amenities: accommodation!.amenities),
                  
                  const SizedBox(height: ThemeConfig.spacingXL),
                  
                  // Location
                  const Text(
                    'Location',
                    style: TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                      color: ThemeConfig.textPrimary,
                    ),
                  ),
                  const SizedBox(height: ThemeConfig.spacingM),
                  LocationMap(
                    latitude: accommodation!.location['latitude'] ?? 0.0,
                    longitude: accommodation!.location['longitude'] ?? 0.0,
                    address: accommodation!.address,
                  ),
                  
                  const SizedBox(height: ThemeConfig.spacingXXL),
                ],
              ),
            ),
          ),
        ],
      ),
      
      // Bottom Bar
      bottomNavigationBar: Container(
        padding: const EdgeInsets.all(ThemeConfig.spacingL),
        decoration: BoxDecoration(
          color: Colors.white,
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.1),
              blurRadius: 10,
              offset: const Offset(0, -2),
            ),
          ],
        ),
        child: Row(
          children: [
            Expanded(
              child: OutlinedButton(
                onPressed: () {
                  // TODO: Contact landlord
                },
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: ThemeConfig.primaryColor),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: ThemeConfig.spacingM),
                ),
                child: const Text('Contact'),
              ),
            ),
            const SizedBox(width: ThemeConfig.spacingM),
            Expanded(
              flex: 2,
              child: ElevatedButton(
                onPressed: accommodation!.isAvailable
                    ? () => context.push('/booking/${accommodation!.id}')
                    : null,
                style: ElevatedButton.styleFrom(
                  backgroundColor: ThemeConfig.primaryColor,
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
                  ),
                  padding: const EdgeInsets.symmetric(vertical: ThemeConfig.spacingM),
                ),
                child: Text(
                  accommodation!.isAvailable ? 'Book Now' : 'Not Available',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
