import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';

import '../../../core/config/theme_config.dart';
import '../providers/accommodation_provider.dart';
import '../widgets/accommodation_card.dart';
import '../widgets/accommodation_filters.dart';
import '../widgets/search_bar.dart';

class AccommodationListScreen extends StatefulWidget {
  const AccommodationListScreen({super.key});

  @override
  State<AccommodationListScreen> createState() => _AccommodationListScreenState();
}

class _AccommodationListScreenState extends State<AccommodationListScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      context.read<AccommodationProvider>().loadAccommodations();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeConfig.backgroundColor,
      appBar: AppBar(
        title: const Text('Find Housing'),
        backgroundColor: Colors.white,
        elevation: 0,
        actions: [
          IconButton(
            icon: const Icon(Icons.filter_list),
            onPressed: () => _showFilters(context),
          ),
        ],
      ),
      body: Column(
        children: [
          // Search Bar
          Container(
            color: Colors.white,
            padding: const EdgeInsets.all(ThemeConfig.spacingM),
            child: Consumer<AccommodationProvider>(
              builder: (context, provider, child) {
                return AccommodationSearchBar(
                  onSearch: provider.searchAccommodations,
                  initialValue: provider.searchQuery,
                );
              },
            ),
          ),
          
          // Accommodations List
          Expanded(
            child: Consumer<AccommodationProvider>(
              builder: (context, provider, child) {
                if (provider.isLoading) {
                  return const Center(child: CircularProgressIndicator());
                }

                if (provider.errorMessage != null) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          provider.errorMessage!,
                          style: const TextStyle(color: ThemeConfig.errorColor),
                        ),
                        const SizedBox(height: ThemeConfig.spacingM),
                        ElevatedButton(
                          onPressed: () => provider.loadAccommodations(),
                          child: const Text('Retry'),
                        ),
                      ],
                    ),
                  );
                }

                if (provider.accommodations.isEmpty) {
                  return const Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.home_outlined,
                          size: 64,
                          color: ThemeConfig.textHint,
                        ),
                        SizedBox(height: ThemeConfig.spacingM),
                        Text(
                          'No accommodations found',
                          style: TextStyle(
                            fontSize: 18,
                            color: ThemeConfig.textSecondary,
                          ),
                        ),
                        SizedBox(height: ThemeConfig.spacingS),
                        Text(
                          'Try adjusting your search or filters',
                          style: TextStyle(
                            fontSize: 14,
                            color: ThemeConfig.textHint,
                          ),
                        ),
                      ],
                    ),
                  );
                }

                return RefreshIndicator(
                  onRefresh: provider.loadAccommodations,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(ThemeConfig.spacingM),
                    itemCount: provider.accommodations.length,
                    itemBuilder: (context, index) {
                      final accommodation = provider.accommodations[index];
                      return AccommodationCard(
                        accommodation: accommodation,
                        onTap: () => context.push('/accommodation/${accommodation.id}'),
                      );
                    },
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  void _showFilters(BuildContext context) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      builder: (context) => const AccommodationFilters(),
    );
  }
}
