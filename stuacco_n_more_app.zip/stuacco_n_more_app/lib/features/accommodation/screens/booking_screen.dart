import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/config/theme_config.dart';
import '../widgets/booking_form.dart';

class BookingScreen extends StatelessWidget {
  final String accommodationId;

  const BookingScreen({
    super.key,
    required this.accommodationId,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Book Accommodation'),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      backgroundColor: ThemeConfig.backgroundColor,
      body: BookingForm(
        accommodationId: accommodationId,
        onBookingComplete: (bookingId) {
          // Navigate to booking confirmation
          context.go('/booking-confirmation/$bookingId');
        },
      ),
    );
  }
}
