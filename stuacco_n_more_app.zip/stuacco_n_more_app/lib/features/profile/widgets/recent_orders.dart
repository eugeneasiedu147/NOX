import 'package:flutter/material.dart';
import '../../../core/config/theme_config.dart';

class RecentOrders extends StatelessWidget {
  const RecentOrders({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: ThemeConfig.spacingL),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Recent Orders',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
              TextButton(
                onPressed: () {
                  // Navigate to all orders
                },
                child: const Text('View All'),
              ),
            ],
          ),
          const SizedBox(height: ThemeConfig.spacingM),
          Container(
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(ThemeConfig.radiusL),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 10,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: [
                _buildOrderItem(
                  orderNumber: '#ORD001',
                  status: 'Delivered',
                  statusColor: ThemeConfig.successColor,
                  date: '2 days ago',
                  amount: '₵145.50',
                  itemCount: 3,
                ),
                const Divider(height: 1),
                _buildOrderItem(
                  orderNumber: '#ORD002',
                  status: 'Processing',
                  statusColor: ThemeConfig.warningColor,
                  date: '1 week ago',
                  amount: '₵89.00',
                  itemCount: 2,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildOrderItem({
    required String orderNumber,
    required String status,
    required Color statusColor,
    required String date,
    required String amount,
    required int itemCount,
  }) {
    return Padding(
      padding: const EdgeInsets.all(ThemeConfig.spacingM),
      child: Row(
        children: [
          Container(
            width: 50,
            height: 50,
            decoration: BoxDecoration(
              color: Colors.grey[300],
              borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
            ),
            child: const Icon(
              Icons.shopping_bag,
              color: Colors.grey,
            ),
          ),
          const SizedBox(width: ThemeConfig.spacingM),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  orderNumber,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '$itemCount items • $date',
                  style: const TextStyle(
                    fontSize: 14,
                    color: ThemeConfig.textSecondary,
                  ),
                ),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: ThemeConfig.spacingS,
                  vertical: 2,
                ),
                decoration: BoxDecoration(
                  color: statusColor.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(ThemeConfig.radiusS),
                ),
                child: Text(
                  status,
                  style: TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                    color: statusColor,
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                amount,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  color: ThemeConfig.primaryColor,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
