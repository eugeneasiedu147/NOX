import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:stuacco_n_more_app/core/models/user_model.dart';

import '../../../core/config/theme_config.dart';
import '../../auth/providers/auth_provider.dart';
import '../widgets/profile_header.dart';
import '../widgets/profile_menu.dart';
import '../widgets/recent_bookings.dart';
import '../widgets/recent_orders.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeConfig.backgroundColor,
      body: SafeArea(
        child: SingleChildScrollView(
          child: Column(
            children: [
              // Profile Header
              Consumer<AuthProvider>(
                builder: (context, authProvider, child) {
                  return ProfileHeader(
                    user: authProvider.currentUser != null
                        ? UserModel.fromUser(authProvider.currentUser!)
                        : null,
                    onEditProfile: () => context.push('/edit-profile'),
                  );
                },
              ),
              
              const SizedBox(height: ThemeConfig.spacingL),
              
              // Profile Menu
              const ProfileMenu(),
              
              const SizedBox(height: ThemeConfig.spacingL),
              
              // Recent Bookings
              const RecentBookings(),
              
              const SizedBox(height: ThemeConfig.spacingL),
              
              // Recent Orders
              const RecentOrders(),
              
              const SizedBox(height: ThemeConfig.spacingXL),
            ],
          ),
        ),
      ),
    );
  }
}
