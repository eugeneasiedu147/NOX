import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';

import '../../../core/config/theme_config.dart';
import '../../auth/providers/auth_provider.dart' hide AuthProvider;
import '../../auth/widgets/auth_text_field.dart';
import '../../auth/widgets/auth_button.dart';

class EditProfileScreen extends StatefulWidget {
  const EditProfileScreen({super.key});

  @override
  State<EditProfileScreen> createState() => _EditProfileScreenState();
}

class _EditProfileScreenState extends State<EditProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _firstNameController = TextEditingController();
  final _lastNameController = TextEditingController();
  final _phoneController = TextEditingController();
  final _institutionController = TextEditingController();
  final _courseController = TextEditingController();
  final _yearController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _loadUserData();
  }

  void _loadUserData() {
    final user = context.read<AuthProvider>().currentUser;
    if (user != null) {
      _firstNameController.text = user.firstName ?? '';
      _lastNameController.text = user.lastName ?? '';
      _phoneController.text = user.phoneNumber ?? '';
      _institutionController.text = user.institution ?? '';
      _courseController.text = user.course ?? '';
      _yearController.text = user.yearOfStudy?.toString() ?? '';
    }
  }

  @override
  void dispose() {
    _firstNameController.dispose();
    _lastNameController.dispose();
    _phoneController.dispose();
    _institutionController.dispose();
    _courseController.dispose();
    _yearController.dispose();
    super.dispose();
  }

  Future<void> _handleUpdateProfile() async {
    if (!_formKey.currentState!.validate()) return;

    final authProvider = context.read<AuthProvider>();
    final success = await authProvider.updateProfile(
      firstName: _firstNameController.text.trim(),
      lastName: _lastNameController.text.trim(),
      phoneNumber: _phoneController.text.trim().isNotEmpty 
          ? _phoneController.text.trim() 
          : null,
      institution: _institutionController.text.trim().isNotEmpty 
          ? _institutionController.text.trim() 
          : null,
      course: _courseController.text.trim().isNotEmpty 
          ? _courseController.text.trim() 
          : null,
      yearOfStudy: _yearController.text.trim().isNotEmpty 
          ? int.tryParse(_yearController.text.trim()) 
          : null,
    );

    if (success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Profile updated successfully')),
      );
      context.pop();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit Profile'),
        backgroundColor: Colors.white,
        elevation: 0,
      ),
      backgroundColor: ThemeConfig.backgroundColor,
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(ThemeConfig.spacingL),
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // Profile Picture
              Center(
                child: Stack(
                  children: [
                    Consumer<AuthProvider>(
                      builder: (context, authProvider, child) {
                        return CircleAvatar(
                          radius: 60,
                          backgroundColor: ThemeConfig.primaryColor.withOpacity(0.1),
                          backgroundImage: authProvider.currentUser?.profileImageUrl != null
                              ? NetworkImage(authProvider.currentUser!.profileImageUrl!)
                              : null,
                          child: authProvider.currentUser?.profileImageUrl == null
                              ? Text(
                                  authProvider.currentUser?.firstName.substring(0, 1).toUpperCase() ?? 'U',
                                  style: const TextStyle(
                                    fontSize: 32,
                                    fontWeight: FontWeight.bold,
                                    color: ThemeConfig.primaryColor,
                                  ),
                                )
                              : null,
                        );
                      },
                    ),
                    Positioned(
                      bottom: 0,
                      right: 0,
                      child: Container(
                        width: 36,
                        height: 36,
                        decoration: BoxDecoration(
                          color: ThemeConfig.primaryColor,
                          borderRadius: BorderRadius.circular(18),
                          border: Border.all(color: Colors.white, width: 2),
                        ),
                        child: const Icon(
                          Icons.camera_alt,
                          size: 20,
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(height: ThemeConfig.spacingXL),
              
              // Name Fields
              Row(
                children: [
                  Expanded(
                    child: AuthTextField(
                      controller: _firstNameController,
                      label: 'First Name',
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Required';
                        }
                        return null;
                      }, hintText: '',
                    ),
                  ),
                  const SizedBox(width: ThemeConfig.spacingM),
                  Expanded(
                    child: AuthTextField(
                      controller: _lastNameController,
                      label: 'Last Name',
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Required';
                        }
                        return null;
                      }, hintText: 'Enter your last name',
                    ),
                  ),
                ],
              ),
              
              const SizedBox(height: ThemeConfig.spacingL),
              
              // Phone Field
              AuthTextField(
                controller: _phoneController,
                label: 'Phone Number',
                keyboardType: TextInputType.phone, hintText: '',
              ),
              
              const SizedBox(height: ThemeConfig.spacingL),
              
              // Institution Field
              AuthTextField(
                controller: _institutionController,
                label: 'Institution', hintText: '',
              ),
              
              const SizedBox(height: ThemeConfig.spacingL),
              
              // Course Field
              AuthTextField(
                controller: _courseController,
                label: 'Course/Program', hintText: '',
              ),
              
              const SizedBox(height: ThemeConfig.spacingL),
              
              // Year of Study
              AuthTextField(
                controller: _yearController,
                label: 'Year of Study',
                keyboardType: TextInputType.number,hintText: '',
              ),
              
              const SizedBox(height: ThemeConfig.spacingXXL),
              
              // Update Button
              Consumer<AuthProvider>(
                builder: (context, authProvider, child) {
                  return AuthButton(
                    text: 'Update Profile',
                    onPressed: _handleUpdateProfile,
                    isLoading: authProvider.isLoading,
                  );
                },
              ),
              
              // Error Message
              Consumer<AuthProvider>(
                builder: (context, authProvider, child) {
                  if (authProvider.errorMessage != null) {
                    return Padding(
                      padding: const EdgeInsets.only(top: ThemeConfig.spacingM),
                      child: Text(
                        authProvider.errorMessage!,
                        style: const TextStyle(
                          color: ThemeConfig.errorColor,
                          fontSize: 14,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    );
                  }
                  return const SizedBox.shrink();
                },
              ),
            ],
          ),
        ),
      ),
    );
  }
}

extension on AuthProvider {
   get currentUser => null;
   
     get errorMessage => null;
     
       get isLoading => null;
   
     Future updateProfile({required String firstName, required String lastName, String? phoneNumber, String? institution, String? course, int? yearOfStudy}) async {
       return;
     }
}

extension on User {
  get lastName => null;
}
