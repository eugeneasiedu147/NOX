import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

import '../../../core/models/user_model.dart';
import '../../../core/models/booking_model.dart';
import '../../../core/models/order_model.dart';
import '../../../core/services/firebase_service.dart';

class ProfileProvider extends ChangeNotifier {
  List<BookingModel> _bookings = [];
  List<OrderModel> _orders = [];
  bool _isLoading = false;
  String? _errorMessage;

  List<BookingModel> get bookings => _bookings;
  List<OrderModel> get orders => _orders;
  bool get isLoading => _isLoading;
  String? get errorMessage => _errorMessage;

  Future<void> loadUserBookings(String userId) async {
    try {
      _setLoading(true);
      _clearError();

      final querySnapshot = await FirebaseService.bookings
          .where('studentId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .get();

      _bookings = querySnapshot.docs
          .map((doc) => BookingModel.fromFirestore(doc))
          .toList();

      notifyListeners();
    } catch (e) {
      _setError('Failed to load bookings');
    } finally {
      _setLoading(false);
    }
  }

  Future<void> loadUserOrders(String userId) async {
    try {
      _setLoading(true);
      _clearError();

      final querySnapshot = await FirebaseService.orders
          .where('customerId', isEqualTo: userId)
          .orderBy('createdAt', descending: true)
          .get();

      _orders = querySnapshot.docs
          .map((doc) => OrderModel.fromFirestore(doc))
          .toList();

      notifyListeners();
    } catch (e) {
      _setError('Failed to load orders');
    } finally {
      _setLoading(false);
    }
  }

  Future<bool> updateUserProfile(UserModel user) async {
    try {
      _setLoading(true);
      _clearError();

      await FirebaseService.users.doc(user.id).update(user.toMap());
      return true;
    } catch (e) {
      _setError('Failed to update profile');
      return false;
    } finally {
      _setLoading(false);
    }
  }

  void _setLoading(bool loading) {
    _isLoading = loading;
    notifyListeners();
  }

  void _setError(String error) {
    _errorMessage = error;
    notifyListeners();
  }

  void _clearError() {
    _errorMessage = null;
    notifyListeners();
  }
}
