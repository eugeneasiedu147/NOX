import 'package:flutter/material.dart';
import '../../../core/config/theme_config.dart';

class OnboardingPageData {
  final String title;
  final String description;
  final String imagePath;
  

  OnboardingPageData({
    required this.title,
    required this.description,
    required this.imagePath,
    
  });
}

class OnboardingPage extends StatelessWidget {
  final OnboardingPageData data;

  const OnboardingPage({
    super.key,
    required this.data,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(ThemeConfig.spacingL),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // Illustration/Icon
          Container(
            width: 200,
            height: 200,
            decoration: BoxDecoration(
              color: ThemeConfig.primaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(100),
            ),
            child: Icon(
              Icons.image, // Replace with appropriate icon or image
              size: 100,
              color: ThemeConfig.primaryColor,
            ),
          ),
          
          const SizedBox(height: ThemeConfig.spacingXXL),
          
          // Title
          Text(
            data.title,
            style: const TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: ThemeConfig.textPrimary,
            ),
            textAlign: TextAlign.center,
          ),
          
          const SizedBox(height: ThemeConfig.spacingL),
          
          // Description
          Text(
            data.description,
            style: const TextStyle(
              fontSize: 16,
              color: ThemeConfig.textSecondary,
              height: 1.5,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}
