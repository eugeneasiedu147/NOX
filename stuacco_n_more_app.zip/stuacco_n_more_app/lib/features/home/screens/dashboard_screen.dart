import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:go_router/go_router.dart';
import 'package:stuacco_n_more_app/core/models/user_model.dart';

import '../../../core/config/theme_config.dart';
import '../../auth/providers/auth_provider.dart';
import '../widgets/dashboard_header.dart';
import '../widgets/quick_actions.dart';
import '../widgets/featured_accommodations.dart';
import '../widgets/featured_products.dart';
import '../widgets/recent_activities.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ThemeConfig.backgroundColor,
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () async {
            // Refresh dashboard data
            await Future.delayed(const Duration(seconds: 1));
          },
          child: SingleChildScrollView(
            physics: const AlwaysScrollableScrollPhysics(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                // Header
                Consumer<AuthProvider>(
                  builder: (context, authProvider, child) {
                    return DashboardHeader(
                      user: authProvider.currentUser == null
                          ? null
                          : UserModel.fromUser(authProvider.currentUser!),
                      onNotificationTap: () => context.push('/notifications'),
                    );
                  },
                ),
                
                const SizedBox(height: ThemeConfig.spacingL),
                
                // Quick Actions
                const QuickActions(),
                
                const SizedBox(height: ThemeConfig.spacingXL),
                
                // Featured Accommodations
                const FeaturedAccommodations(),
                
                const SizedBox(height: ThemeConfig.spacingXL),
                
                // Featured Products
                const FeaturedProducts(),
                
                const SizedBox(height: ThemeConfig.spacingXL),
                
                // Recent Activities
                const RecentActivities(),
                
                const SizedBox(height: ThemeConfig.spacingXL),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
