import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../../core/config/theme_config.dart';

class QuickActions extends StatelessWidget {
  const QuickActions({super.key});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: ThemeConfig.spacingL),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Quick Actions',
            style: TextStyle(
              fontSize: 20,
              fontWeight: FontWeight.bold,
              color: ThemeConfig.textPrimary,
            ),
          ),
          const SizedBox(height: ThemeConfig.spacingM),
          Row(
            children: [
              Expanded(
                child: _QuickActionCard(
                  icon: Icons.search,
                  title: 'Find Housing',
                  subtitle: 'Search accommodations',
                  color: ThemeConfig.primaryColor,
                  onTap: () => context.push('/accommodations'),
                ),
              ),
              const SizedBox(width: ThemeConfig.spacingM),
              Expanded(
                child: _QuickActionCard(
                  icon: Icons.shopping_cart,
                  title: 'Shop Now',
                  subtitle: 'Browse essentials',
                  color: ThemeConfig.secondaryColor,
                  onTap: () => context.push('/store'),
                ),
              ),
            ],
          ),
          const SizedBox(height: ThemeConfig.spacingM),
          Row(
            children: [
              Expanded(
                child: _QuickActionCard(
                  icon: Icons.payment,
                  title: 'Pay Rent',
                  subtitle: 'Make payments',
                  color: ThemeConfig.accentColor,
                  onTap: () {
                    // Navigate to payment screen
                  },
                ),
              ),
              const SizedBox(width: ThemeConfig.spacingM),
              Expanded(
                child: _QuickActionCard(
                  icon: Icons.support_agent,
                  title: 'Support',
                  subtitle: 'Get help',
                  color: ThemeConfig.warningColor,
                  onTap: () {
                    // Navigate to support screen
                  },
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _QuickActionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color color;
  final VoidCallback onTap;

  const _QuickActionCard({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.color,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(ThemeConfig.spacingM),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(ThemeConfig.radiusL),
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 2),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: color.withOpacity(0.1),
                borderRadius: BorderRadius.circular(ThemeConfig.radiusM),
              ),
              child: Icon(
                icon,
                color: color,
                size: 24,
              ),
            ),
            const SizedBox(height: ThemeConfig.spacingM),
            Text(
              title,
              style: const TextStyle(
                fontSize: 16,
                fontWeight: FontWeight.w600,
                color: ThemeConfig.textPrimary,
              ),
            ),
            const SizedBox(height: ThemeConfig.spacingXS),
            Text(
              subtitle,
              style: const TextStyle(
                fontSize: 12,
                color: ThemeConfig.textSecondary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
