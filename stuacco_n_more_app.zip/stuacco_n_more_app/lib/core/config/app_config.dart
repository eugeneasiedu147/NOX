class AppConfig {
  // App Information
  static const String appName = 'STUACCO-N-MORE';
  static const String appVersion = '1.0.0';
  static const String companyName = 'AGILE COSTAPRICE LTD';
  
  // API Configuration
  static const String baseUrl = 'https://api.stuacco.com';
  static const String apiVersion = 'v1';
  
  // Payment Configuration
  static const String paystackPublicKey = 'pk_test_9b2120a8562ce8ca19f89f696b6ca70baca6c03f';
  static const String paystackSecretKey = 'sk_test_54e9330a22e15665d72ae46260c1917b73fcd9e0';
  
  // Maps Configuration
  static const String googleMapsApiKey = 'AIzaSyD76orWlt9Vyd5rmzK_JBrR59rC1GSaa9Y';
  
  // Firebase Configuration
  static const String firebaseWebApiKey = 'your_firebase_web_api_key';
  
  // Support Information
  static const String supportEmail = 'support@stuacco.com';
  static const String supportPhone = '+233123456789';
  static const String whatsappNumber = '+233123456789';
  
  // Social Media
  static const String facebookUrl = 'https://facebook.com/stuacco';
  static const String twitterUrl = 'https://twitter.com/stuacco';
  static const String instagramUrl = 'https://instagram.com/stuacco';
  
  // Terms and Privacy
  static const String termsUrl = 'https://stuacco.com/terms';
  static const String privacyUrl = 'https://stuacco.com/privacy';
  
  // App Store Links
  static const String playStoreUrl = 'https://play.google.com/store/apps/details?id=com.stuacco.app';
  static const String appStoreUrl = 'https://apps.apple.com/app/stuacco/id123456789';
  
  // Feature Flags
  static const bool enableVirtualTours = false;
  static const bool enableWalletSystem = false;
  static const bool enableMultiLanguage = false;
  static const bool enableReferralProgram = true;
  
  // Pagination
  static const int defaultPageSize = 20;
  static const int maxPageSize = 100;
  
  // File Upload Limits
  static const int maxImageSize = 5 * 1024 * 1024; // 5MB
  static const int maxDocumentSize = 10 * 1024 * 1024; // 10MB
  static const List<String> allowedImageTypes = ['jpg', 'jpeg', 'png', 'webp'];
  static const List<String> allowedDocumentTypes = ['pdf', 'doc', 'docx'];
  
  // Cache Configuration
  static const Duration cacheExpiration = Duration(hours: 24);
  static const int maxCacheSize = 100 * 1024 * 1024; // 100MB
}
