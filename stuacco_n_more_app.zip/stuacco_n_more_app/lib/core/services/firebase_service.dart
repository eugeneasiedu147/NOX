import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

class FirebaseService {
  // Firebase instances
  static final FirebaseAuth auth = FirebaseAuth.instance;
  static final FirebaseFirestore firestore = FirebaseFirestore.instance;
  static final FirebaseStorage storage = FirebaseStorage.instance;
  
  // Collection references
  static CollectionReference get users => firestore.collection('users');
  static CollectionReference get accommodations => firestore.collection('accommodations');
  static CollectionReference get products => firestore.collection('products');
  static CollectionReference get bookings => firestore.collection('bookings');
  static CollectionReference get orders => firestore.collection('orders');
  static CollectionReference get reviews => firestore.collection('reviews');
  static CollectionReference get notifications => firestore.collection('notifications');
  static CollectionReference get maintenanceRequests => firestore.collection('maintenance_requests');
  static CollectionReference get payments => firestore.collection('payments');
  static CollectionReference get chats => firestore.collection('chats');
  
  // Storage references
  static Reference get userImages => storage.ref().child('users');
  static Reference get accommodationImages => storage.ref().child('accommodations');
  static Reference get productImages => storage.ref().child('products');
  static Reference get documents => storage.ref().child('documents');
  static Reference get chatFiles => storage.ref().child('chats');
  
  // Helper methods
  static String generateId() => firestore.collection('temp').doc().id;
  
  static Future<void> initializeApp() async {
    try {
      // Set Firestore settings
      await firestore.settings;
      
      // Enable offline persistence
      await firestore.enableNetwork();
      
      print('Firebase initialized successfully');
    } catch (e) {
      print('Error initializing Firebase: $e');
      rethrow;
    }
  }
  
  static Future<void> signOut() async {
    try {
      await auth.signOut();
    } catch (e) {
      print('Error signing out: $e');
      rethrow;
    }
  }
  
  static Future<String?> uploadFile(String path, String fileName, dynamic fileData) async {
    try {
      final ref = storage.ref().child(path).child(fileName);
      final uploadTask = await ref.putData(fileData);
      return await uploadTask.ref.getDownloadURL();
    } catch (e) {
      print('Error uploading file: $e');
      return null;
    }
  }
  
  static Future<bool> deleteFile(String url) async {
    try {
      final ref = storage.refFromURL(url);
      await ref.delete();
      return true;
    } catch (e) {
      print('Error deleting file: $e');
      return false;
    }
  }
  
  // Batch operations
  static WriteBatch batch() => firestore.batch();
  
  // Transactions
  static Future<T> runTransaction<T>(
    Future<T> Function(Transaction transaction) updateFunction,
  ) {
    return firestore.runTransaction(updateFunction);
  }
  
  // Real-time listeners
  static Stream<QuerySnapshot> streamCollection(
    String collection, {
    Query Function(CollectionReference)? queryBuilder,
  }) {
    final ref = firestore.collection(collection);
    return queryBuilder != null ? queryBuilder(ref).snapshots() : ref.snapshots();
  }
  
  static Stream<DocumentSnapshot> streamDocument(String collection, String id) {
    return firestore.collection(collection).doc(id).snapshots();
  }
}
