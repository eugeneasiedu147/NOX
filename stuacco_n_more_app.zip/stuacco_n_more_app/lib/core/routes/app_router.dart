import 'package:go_router/go_router.dart';

import '../../features/onboarding/screens/splash_screen.dart';
import '../../features/onboarding/screens/onboarding_screen.dart';
import '../../features/auth/screens/login_screen.dart';
import '../../features/auth/screens/register_screen.dart';
import '../../features/auth/screens/forgot_password_screen.dart';
import '../../features/home/screens/main_screen.dart';
import '../../features/accommodation/screens/accommodation_list_screen.dart';
import '../../features/accommodation/screens/accommodation_detail_screen.dart';
import '../../features/accommodation/screens/booking_screen.dart';
import '../../features/store/screens/store_screen.dart';
import '../../features/store/screens/product_detail_screen.dart';
import '../../features/store/screens/cart_screen.dart';
import '../../features/store/screens/checkout_screen.dart';
import '../../features/profile/screens/profile_screen.dart';
import '../../features/profile/screens/edit_profile_screen.dart';
import '../../features/notifications/screens/notifications_screen.dart';

class AppRouter {
  static final GoRouter router = GoRouter(
    initialLocation: '/splash',
    routes: [
      // Onboarding Routes
      GoRoute(
        path: '/splash',
        builder: (context, state) => const SplashScreen(),
      ),
      GoRoute(
        path: '/onboarding',
        builder: (context, state) => const OnboardingScreen(),
      ),
      
      // Auth Routes
      GoRoute(
        path: '/login',
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: '/register',
        builder: (context, state) => const RegisterScreen(),
      ),
      GoRoute(
        path: '/forgot-password',
        builder: (context, state) => const ForgotPasswordScreen(),
      ),
      
      // Main App Routes
      GoRoute(
        path: '/main',
        builder: (context, state) => const MainScreen(),
      ),
      
      // Accommodation Routes
      GoRoute(
        path: '/accommodations',
        builder: (context, state) => const AccommodationListScreen(),
      ),
      GoRoute(
        path: '/accommodation/:id',
        builder: (context, state) => AccommodationDetailScreen(
          accommodationId: state.pathParameters['id']!,
        ),
      ),
      GoRoute(
        path: '/booking/:accommodationId',
        builder: (context, state) => BookingScreen(
          accommodationId: state.pathParameters['accommodationId']!,
        ),
      ),
      
      // Store Routes
      GoRoute(
        path: '/store',
        builder: (context, state) => const StoreScreen(),
      ),
      GoRoute(
        path: '/product/:id',
        builder: (context, state) => ProductDetailScreen(
          productId: state.pathParameters['id']!,
        ),
      ),
      GoRoute(
        path: '/cart',
        builder: (context, state) => const CartScreen(),
      ),
      GoRoute(
        path: '/checkout',
        builder: (context, state) => const CheckoutScreen(),
      ),
      
      // Profile Routes
      GoRoute(
        path: '/profile',
        builder: (context, state) => const ProfileScreen(),
      ),
      GoRoute(
        path: '/edit-profile',
        builder: (context, state) => const EditProfileScreen(),
      ),
      
      // Notifications
      GoRoute(
        path: '/notifications',
        builder: (context, state) => const NotificationsScreen(),
      ),
    ],
  );
}
