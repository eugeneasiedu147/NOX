import 'package:cloud_firestore/cloud_firestore.dart';

enum UserRole { student, landlord, admin }

class UserModel {
  final String id;
  final String email;
  final String firstName;
  final String lastName;
  final String? phoneNumber;
  final UserRole role;
  final String? profileImageUrl;
  final String? studentId;
  final String? institution;
  final bool isEmailVerified;
  final bool isPhoneVerified;
  final bool isActive;
  final DateTime createdAt;
  final DateTime updatedAt;
  final Map<String, dynamic> preferences;
  final List<String> favoriteAccommodations;
  final List<String> favoriteProducts;

  UserModel({
    required this.id,
    required this.email,
    required this.firstName,
    required this.lastName,
    this.phoneNumber,
    required this.role,
    this.profileImageUrl,
    this.studentId,
    this.institution,
    this.isEmailVerified = false,
    this.isPhoneVerified = false,
    this.isActive = true,
    required this.createdAt,
    required this.updatedAt,
    this.preferences = const {},
    this.favoriteAccommodations = const [],
    this.favoriteProducts = const [],
  });

  String get fullName => '$firstName $lastName';
  
  String get displayName => fullName;
  
  bool get isStudent => role == UserRole.student;
  
  bool get isLandlord => role == UserRole.landlord;
  
  bool get isAdmin => role == UserRole.admin;

  String get roleDisplayName {
    switch (role) {
      case UserRole.student:
        return 'Student';
      case UserRole.landlord:
        return 'Landlord';
      case UserRole.admin:
        return 'Admin';
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'email': email,
      'firstName': firstName,
      'lastName': lastName,
      'phoneNumber': phoneNumber,
      'role': role.name,
      'profileImageUrl': profileImageUrl,
      'studentId': studentId,
      'institution': institution,
      'isEmailVerified': isEmailVerified,
      'isPhoneVerified': isPhoneVerified,
      'isActive': isActive,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'preferences': preferences,
      'favoriteAccommodations': favoriteAccommodations,
      'favoriteProducts': favoriteProducts,
    };
  }

  factory UserModel.fromMap(Map<String, dynamic> map) {
    return UserModel(
      id: map['id'] ?? '',
      email: map['email'] ?? '',
      firstName: map['firstName'] ?? '',
      lastName: map['lastName'] ?? '',
      phoneNumber: map['phoneNumber'],
      role: UserRole.values.firstWhere(
        (e) => e.name == map['role'],
        orElse: () => UserRole.student,
      ),
      profileImageUrl: map['profileImageUrl'],
      studentId: map['studentId'],
      institution: map['institution'],
      isEmailVerified: map['isEmailVerified'] ?? false,
      isPhoneVerified: map['isPhoneVerified'] ?? false,
      isActive: map['isActive'] ?? true,
      createdAt: DateTime.parse(map['createdAt']),
      updatedAt: DateTime.parse(map['updatedAt']),
      preferences: Map<String, dynamic>.from(map['preferences'] ?? {}),
      favoriteAccommodations: List<String>.from(map['favoriteAccommodations'] ?? []),
      favoriteProducts: List<String>.from(map['favoriteProducts'] ?? []),
    );
  }

  factory UserModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return UserModel.fromMap({...data, 'id': doc.id});
  }

  UserModel copyWith({
    String? email,
    String? firstName,
    String? lastName,
    String? phoneNumber,
    UserRole? role,
    String? profileImageUrl,
    String? studentId,
    String? institution,
    bool? isEmailVerified,
    bool? isPhoneVerified,
    bool? isActive,
    DateTime? updatedAt,
    Map<String, dynamic>? preferences,
    List<String>? favoriteAccommodations,
    List<String>? favoriteProducts, String? course, int? yearOfStudy,
  }) {
    return UserModel(
      id: id,
      email: email ?? this.email,
      firstName: firstName ?? this.firstName,
      lastName: lastName ?? this.lastName,
      phoneNumber: phoneNumber ?? this.phoneNumber,
      role: role ?? this.role,
      profileImageUrl: profileImageUrl ?? this.profileImageUrl,
      studentId: studentId ?? this.studentId,
      institution: institution ?? this.institution,
      isEmailVerified: isEmailVerified ?? this.isEmailVerified,
      isPhoneVerified: isPhoneVerified ?? this.isPhoneVerified,
      isActive: isActive ?? this.isActive,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      preferences: preferences ?? this.preferences,
      favoriteAccommodations: favoriteAccommodations ?? this.favoriteAccommodations,
      favoriteProducts: favoriteProducts ?? this.favoriteProducts,
    );
  }

  // Add this static method to create a UserModel from another user object
  static UserModel fromUser(dynamic user) {
    // Replace the following with actual mapping logic based on your user object structure
    return UserModel(
      id: '',
      email: '',
      firstName: '',
      lastName: '',
      role: UserRole.student,
      createdAt: DateTime.now(),
      updatedAt: DateTime.now(),
      // Example: id: user.id, name: user.name, etc.
    );
  }
}
