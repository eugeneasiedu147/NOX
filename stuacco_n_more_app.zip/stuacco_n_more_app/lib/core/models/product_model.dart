import 'package:cloud_firestore/cloud_firestore.dart';

enum ProductCategory {
  furniture,
  kitchenware,
  stationery,
  electronics,
  bedding,
  cleaning,
  personalCare,
  foodBeverages,
  books,
  other
}

enum ProductStatus { available, outOfStock, discontinued }

class ProductModel {
  final String id;
  final String name;
  final String description;
  final ProductCategory category;
  final double price;
  final String currency;
  final List<String> imageUrls;
  final int stockQuantity;
  final ProductStatus status;
  final String sellerId;
  final Map<String, dynamic> specifications;
  final List<String> tags;
  final double rating;
  final int reviewCount;
  final bool isDigital;
  final double? weight;
  final Map<String, double>? dimensions;
  final DateTime createdAt;
  final DateTime updatedAt;
  final bool isActive;
  final bool isFeatured;
  final double? discountPercentage;

  ProductModel({
    required this.id,
    required this.name,
    required this.description,
    required this.category,
    required this.price,
    this.currency = 'GHS',
    required this.imageUrls,
    required this.stockQuantity,
    this.status = ProductStatus.available,
    required this.sellerId,
    required this.specifications,
    required this.tags,
    this.rating = 0.0,
    this.reviewCount = 0,
    this.isDigital = false,
    this.weight,
    this.dimensions,
    required this.createdAt,
    required this.updatedAt,
    this.isActive = true,
    this.isFeatured = false,
    this.discountPercentage,
  });

  double get discountedPrice {
    if (discountPercentage != null && discountPercentage! > 0) {
      return price * (1 - discountPercentage! / 100);
    }
    return price;
  }

  bool get isAvailable => status == ProductStatus.available && stockQuantity > 0 && isActive;

  bool get hasDiscount => discountPercentage != null && discountPercentage! > 0;

  String get formattedPrice => '₵${price.toStringAsFixed(2)}';

  String get formattedDiscountedPrice => '₵${discountedPrice.toStringAsFixed(2)}';

  String get categoryDisplayName {
    switch (category) {
      case ProductCategory.furniture:
        return 'Furniture';
      case ProductCategory.kitchenware:
        return 'Kitchenware';
      case ProductCategory.stationery:
        return 'Stationery';
      case ProductCategory.electronics:
        return 'Electronics';
      case ProductCategory.bedding:
        return 'Bedding';
      case ProductCategory.cleaning:
        return 'Cleaning';
      case ProductCategory.personalCare:
        return 'Personal Care';
      case ProductCategory.foodBeverages:
        return 'Food & Beverages';
      case ProductCategory.books:
        return 'Books';
      case ProductCategory.other:
        return 'Other';
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'category': category.name,
      'price': price,
      'currency': currency,
      'imageUrls': imageUrls,
      'stockQuantity': stockQuantity,
      'status': status.name,
      'sellerId': sellerId,
      'specifications': specifications,
      'tags': tags,
      'rating': rating,
      'reviewCount': reviewCount,
      'isDigital': isDigital,
      'weight': weight,
      'dimensions': dimensions,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'isActive': isActive,
      'isFeatured': isFeatured,
      'discountPercentage': discountPercentage,
    };
  }

  factory ProductModel.fromMap(Map<String, dynamic> map) {
    return ProductModel(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      description: map['description'] ?? '',
      category: ProductCategory.values.firstWhere(
        (e) => e.name == map['category'],
        orElse: () => ProductCategory.other,
      ),
      price: (map['price'] ?? 0.0).toDouble(),
      currency: map['currency'] ?? 'GHS',
      imageUrls: List<String>.from(map['imageUrls'] ?? []),
      stockQuantity: map['stockQuantity'] ?? 0,
      status: ProductStatus.values.firstWhere(
        (e) => e.name == map['status'],
        orElse: () => ProductStatus.available,
      ),
      sellerId: map['sellerId'] ?? '',
      specifications: Map<String, dynamic>.from(map['specifications'] ?? {}),
      tags: List<String>.from(map['tags'] ?? []),
      rating: (map['rating'] ?? 0.0).toDouble(),
      reviewCount: map['reviewCount'] ?? 0,
      isDigital: map['isDigital'] ?? false,
      weight: map['weight']?.toDouble(),
      dimensions: map['dimensions'] != null
          ? Map<String, double>.from(map['dimensions'])
          : null,
      createdAt: DateTime.parse(map['createdAt']),
      updatedAt: DateTime.parse(map['updatedAt']),
      isActive: map['isActive'] ?? true,
      isFeatured: map['isFeatured'] ?? false,
      discountPercentage: map['discountPercentage']?.toDouble(),
    );
  }

  factory ProductModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return ProductModel.fromMap({...data, 'id': doc.id});
  }

  ProductModel copyWith({
    String? name,
    String? description,
    ProductCategory? category,
    double? price,
    String? currency,
    List<String>? imageUrls,
    int? stockQuantity,
    ProductStatus? status,
    Map<String, dynamic>? specifications,
    List<String>? tags,
    double? rating,
    int? reviewCount,
    bool? isDigital,
    double? weight,
    Map<String, double>? dimensions,
    DateTime? updatedAt,
    bool? isActive,
    bool? isFeatured,
    double? discountPercentage,
  }) {
    return ProductModel(
      id: id,
      name: name ?? this.name,
      description: description ?? this.description,
      category: category ?? this.category,
      price: price ?? this.price,
      currency: currency ?? this.currency,
      imageUrls: imageUrls ?? this.imageUrls,
      stockQuantity: stockQuantity ?? this.stockQuantity,
      status: status ?? this.status,
      sellerId: sellerId,
      specifications: specifications ?? this.specifications,
      tags: tags ?? this.tags,
      rating: rating ?? this.rating,
      reviewCount: reviewCount ?? this.reviewCount,
      isDigital: isDigital ?? this.isDigital,
      weight: weight ?? this.weight,
      dimensions: dimensions ?? this.dimensions,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      isActive: isActive ?? this.isActive,
      isFeatured: isFeatured ?? this.isFeatured,
      discountPercentage: discountPercentage ?? this.discountPercentage,
    );
  }
}
