import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:stuacco_n_more_app/core/models/booking_model.dart';

enum OrderStatus {
  pending,
  confirmed,
  processing,
  shipped,
  delivered,
  cancelled,
  refunded
}

enum DeliveryMethod { pickup, delivery, digital }

class OrderItem {
  final String productId;
  final String productName;
  final String productImage;
  final double price;
  final int quantity;
  final Map<String, dynamic> specifications;

  OrderItem({
    required this.productId,
    required this.productName,
    required this.productImage,
    required this.price,
    required this.quantity,
    required this.specifications,
  });

  double get totalPrice => price * quantity;

  Map<String, dynamic> toMap() {
    return {
      'productId': productId,
      'productName': productName,
      'productImage': productImage,
      'price': price,
      'quantity': quantity,
      'specifications': specifications,
    };
  }

  factory OrderItem.fromMap(Map<String, dynamic> map) {
    return OrderItem(
      productId: map['productId'] ?? '',
      productName: map['productName'] ?? '',
      productImage: map['productImage'] ?? '',
      price: (map['price'] ?? 0.0).toDouble(),
      quantity: map['quantity'] ?? 0,
      specifications: Map<String, dynamic>.from(map['specifications'] ?? {}),
    );
  }
}

class OrderModel {
  final String id;
  final String customerId;
  final List<OrderItem> items;
  final double subtotal;
  final double deliveryFee;
  final double tax;
  final double discount;
  final double totalAmount;
  final String currency;
  final OrderStatus status;
  final PaymentStatus paymentStatus;
  final DeliveryMethod deliveryMethod;
  final Map<String, dynamic> deliveryAddress;
  final Map<String, dynamic> paymentDetails;
  final String? trackingNumber;
  final String? notes;
  final DateTime estimatedDelivery;
  final DateTime? deliveredAt;
  final DateTime createdAt;
  final DateTime updatedAt;

  OrderModel({
    required this.id,
    required this.customerId,
    required this.items,
    required this.subtotal,
    this.deliveryFee = 0,
    this.tax = 0,
    this.discount = 0,
    required this.totalAmount,
    this.currency = 'GHS',
    this.status = OrderStatus.pending,
    this.paymentStatus = PaymentStatus.pending,
    this.deliveryMethod = DeliveryMethod.delivery,
    required this.deliveryAddress,
    required this.paymentDetails,
    this.trackingNumber,
    this.notes,
    required this.estimatedDelivery,
    this.deliveredAt,
    required this.createdAt,
    required this.updatedAt,
  });

  int get itemCount => items.fold(0, (sum, item) => sum + item.quantity);

  bool get isDelivered => status == OrderStatus.delivered;

  bool get isCancelled => status == OrderStatus.cancelled;

  bool get isRefunded => status == OrderStatus.refunded;

  bool get canCancel => status == OrderStatus.pending || status == OrderStatus.confirmed;

  String get statusDisplayName {
    switch (status) {
      case OrderStatus.pending:
        return 'Pending';
      case OrderStatus.confirmed:
        return 'Confirmed';
      case OrderStatus.processing:
        return 'Processing';
      case OrderStatus.shipped:
        return 'Shipped';
      case OrderStatus.delivered:
        return 'Delivered';
      case OrderStatus.cancelled:
        return 'Cancelled';
      case OrderStatus.refunded:
        return 'Refunded';
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'customerId': customerId,
      'items': items.map((item) => item.toMap()).toList(),
      'subtotal': subtotal,
      'deliveryFee': deliveryFee,
      'tax': tax,
      'discount': discount,
      'totalAmount': totalAmount,
      'currency': currency,
      'status': status.name,
      'paymentStatus': paymentStatus.name,
      'deliveryMethod': deliveryMethod.name,
      'deliveryAddress': deliveryAddress,
      'paymentDetails': paymentDetails,
      'trackingNumber': trackingNumber,
      'notes': notes,
      'estimatedDelivery': estimatedDelivery.toIso8601String(),
      'deliveredAt': deliveredAt?.toIso8601String(),
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
    };
  }

  factory OrderModel.fromMap(Map<String, dynamic> map) {
    return OrderModel(
      id: map['id'] ?? '',
      customerId: map['customerId'] ?? '',
      items: (map['items'] as List<dynamic>)
          .map((item) => OrderItem.fromMap(item))
          .toList(),
      subtotal: (map['subtotal'] ?? 0.0).toDouble(),
      deliveryFee: (map['deliveryFee'] ?? 0.0).toDouble(),
      tax: (map['tax'] ?? 0.0).toDouble(),
      discount: (map['discount'] ?? 0.0).toDouble(),
      totalAmount: (map['totalAmount'] ?? 0.0).toDouble(),
      currency: map['currency'] ?? 'GHS',
      status: OrderStatus.values.firstWhere(
        (e) => e.name == map['status'],
        orElse: () => OrderStatus.pending,
      ),
      paymentStatus: PaymentStatus.values.firstWhere(
        (e) => e.name == map['paymentStatus'],
        orElse: () => PaymentStatus.pending,
      ),
      deliveryMethod: DeliveryMethod.values.firstWhere(
        (e) => e.name == map['deliveryMethod'],
        orElse: () => DeliveryMethod.delivery,
      ),
      deliveryAddress: Map<String, dynamic>.from(map['deliveryAddress'] ?? {}),
      paymentDetails: Map<String, dynamic>.from(map['paymentDetails'] ?? {}),
      trackingNumber: map['trackingNumber'],
      notes: map['notes'],
      estimatedDelivery: DateTime.parse(map['estimatedDelivery']),
      deliveredAt: map['deliveredAt'] != null 
          ? DateTime.parse(map['deliveredAt']) 
          : null,
      createdAt: DateTime.parse(map['createdAt']),
      updatedAt: DateTime.parse(map['updatedAt']),
    );
  }

  factory OrderModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return OrderModel.fromMap({...data, 'id': doc.id});
  }

  OrderModel copyWith({
    OrderStatus? status,
    PaymentStatus? paymentStatus,
    String? trackingNumber,
    String? notes,
    DateTime? estimatedDelivery,
    DateTime? deliveredAt,
    DateTime? updatedAt,
  }) {
    return OrderModel(
      id: id,
      customerId: customerId,
      items: items,
      subtotal: subtotal,
      deliveryFee: deliveryFee,
      tax: tax,
      discount: discount,
      totalAmount: totalAmount,
      currency: currency,
      status: status ?? this.status,
      paymentStatus: paymentStatus ?? this.paymentStatus,
      deliveryMethod: deliveryMethod,
      deliveryAddress: deliveryAddress,
      paymentDetails: paymentDetails,
      trackingNumber: trackingNumber ?? this.trackingNumber,
      notes: notes ?? this.notes,
      estimatedDelivery: estimatedDelivery ?? this.estimatedDelivery,
      deliveredAt: deliveredAt ?? this.deliveredAt,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
    );
  }
}
