import 'package:cloud_firestore/cloud_firestore.dart';

enum AccommodationType { hostel, apartment, room, house }
enum AccommodationStatus { available, occupied, maintenance, inactive }

class AccommodationModel {
  final String id;
  final String name;
  final String description;
  final AccommodationType type;
  final AccommodationStatus status;
  final String landlordId;
  final List<String> imageUrls;
  final double price;
  final String currency;
  final String priceType; // monthly, semester, yearly
  final Map<String, dynamic> location;
  final List<String> amenities;
  final Map<String, dynamic> specifications;
  final int capacity;
  final int availableSpaces;
  final double rating;
  final int reviewCount;
  final List<String> tags;
  final bool isVerified;
  final bool isFeatured;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? availableFrom;
  final Map<String, dynamic> rules;
  final Map<String, dynamic> contact;
  final String title;
  final String address;
  final double latitude;
  final double longitude;
  final int maxOccupants;

  AccommodationModel({
    required this.id,
    required this.name,
    required this.description,
    required this.type,
    this.status = AccommodationStatus.available,
    required this.landlordId,
    required this.imageUrls,
    required this.price,
    this.currency = 'GHS',
    this.priceType = 'monthly',
    required this.location,
    required this.amenities,
    required this.specifications,
    required this.capacity,
    required this.availableSpaces,
    this.rating = 0.0,
    this.reviewCount = 0,
    required this.tags,
    this.isVerified = false,
    this.isFeatured = false,
    required this.createdAt,
    required this.updatedAt,
    this.availableFrom,
    required this.rules,
    required this.contact,
    required this.title,
    required this.address,
    required this.latitude,
    required this.maxOccupants,
    required this.longitude,
  });

  bool get isAvailable => status == AccommodationStatus.available && availableSpaces > 0;
  
  String get formattedPrice => '₵${price.toStringAsFixed(2)}';
  
  String get priceDisplay => '$formattedPrice/$priceType';

  String get typeDisplayName {
    switch (type) {
      case AccommodationType.hostel:
        return 'Hostel';
      case AccommodationType.apartment:
        return 'Apartment';
      case AccommodationType.room:
        return 'Room';
      case AccommodationType.house:
        return 'House';
    }
  }

  String get statusDisplayName {
    switch (status) {
      case AccommodationStatus.available:
        return 'Available';
      case AccommodationStatus.occupied:
        return 'Occupied';
      case AccommodationStatus.maintenance:
        return 'Under Maintenance';
      case AccommodationStatus.inactive:
        return 'Inactive';
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'type': type.name,
      'status': status.name,
      'landlordId': landlordId,
      'imageUrls': imageUrls,
      'price': price,
      'currency': currency,
      'priceType': priceType,
      'location': location,
      'amenities': amenities,
      'specifications': specifications,
      'capacity': capacity,
      'availableSpaces': availableSpaces,
      'rating': rating,
      'reviewCount': reviewCount,
      'tags': tags,
      'isVerified': isVerified,
      'isFeatured': isFeatured,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'availableFrom': availableFrom?.toIso8601String(),
      'rules': rules,
      'contact': contact,
      'title': title,
      'address': address,
      'latitude': latitude,
      'longitude': longitude,
      'maxOccupants': maxOccupants,
    };
  }

  factory AccommodationModel.fromMap(Map<String, dynamic> map) {
    return AccommodationModel(
      id: map['id'] ?? '',
      name: map['name'] ?? '',
      description: map['description'] ?? '',
      type: AccommodationType.values.firstWhere(
        (e) => e.name == map['type'],
        orElse: () => AccommodationType.room,
      ),
      status: AccommodationStatus.values.firstWhere(
        (e) => e.name == map['status'],
        orElse: () => AccommodationStatus.available,
      ),
      landlordId: map['landlordId'] ?? '',
      imageUrls: List<String>.from(map['imageUrls'] ?? []),
      price: (map['price'] ?? 0.0).toDouble(),
      currency: map['currency'] ?? 'GHS',
      priceType: map['priceType'] ?? 'monthly',
      location: Map<String, dynamic>.from(map['location'] ?? {}),
      amenities: List<String>.from(map['amenities'] ?? []),
      specifications: Map<String, dynamic>.from(map['specifications'] ?? {}),
      capacity: map['capacity'] ?? 0,
      availableSpaces: map['availableSpaces'] ?? 0,
      rating: (map['rating'] ?? 0.0).toDouble(),
      reviewCount: map['reviewCount'] ?? 0,
      tags: List<String>.from(map['tags'] ?? []),
      isVerified: map['isVerified'] ?? false,
      isFeatured: map['isFeatured'] ?? false,
      createdAt: DateTime.parse(map['createdAt']),
      updatedAt: DateTime.parse(map['updatedAt']),
      availableFrom: map['availableFrom'] != null 
          ? DateTime.parse(map['availableFrom']) 
          : null,
      rules: Map<String, dynamic>.from(map['rules'] ?? {}),
      contact: Map<String, dynamic>.from(map['contact'] ?? {}),
      title: map['title'] ?? '',
      address: map['address'] ?? '',
      latitude: (map['latitude'] ?? 0.0).toDouble(),
      maxOccupants: map['maxOccupants'] ?? 0,
      longitude: (map['longitude'] ?? 0.0).toDouble(),
    );
  }

  factory AccommodationModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return AccommodationModel.fromMap({...data, 'id': doc.id});
  }

  AccommodationModel copyWith({
    String? name,
    String? description,
    AccommodationType? type,
    AccommodationStatus? status,
    List<String>? imageUrls,
    double? price,
    String? priceType,
    Map<String, dynamic>? location,
    List<String>? amenities,
    Map<String, dynamic>? specifications,
    int? capacity,
    int? availableSpaces,
    double? rating,
    int? reviewCount,
    List<String>? tags,
    bool? isVerified,
    bool? isFeatured,
    DateTime? updatedAt,
    DateTime? availableFrom,
    Map<String, dynamic>? rules,
    Map<String, dynamic>? contact,
    String? title,
    String? address,
    double? latitude,
    double? longitude,
    int? maxOccupants,
  }) {
    return AccommodationModel(
      id: id,
      name: name ?? this.name,
      description: description ?? this.description,
      type: type ?? this.type,
      status: status ?? this.status,
      landlordId: landlordId,
      imageUrls: imageUrls ?? this.imageUrls,
      price: price ?? this.price,
      currency: currency,
      priceType: priceType ?? this.priceType,
      location: location ?? this.location,
      amenities: amenities ?? this.amenities,
      specifications: specifications ?? this.specifications,
      capacity: capacity ?? this.capacity,
      availableSpaces: availableSpaces ?? this.availableSpaces,
      rating: rating ?? this.rating,
      reviewCount: reviewCount ?? this.reviewCount,
      tags: tags ?? this.tags,
      isVerified: isVerified ?? this.isVerified,
      isFeatured: isFeatured ?? this.isFeatured,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      availableFrom: availableFrom ?? this.availableFrom,
      rules: rules ?? this.rules,
      contact: contact ?? this.contact,
      title: title ?? this.title,
      address: address ?? this.address,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      maxOccupants: maxOccupants ?? this.maxOccupants,
    );
  }
}
