import 'package:cloud_firestore/cloud_firestore.dart';

enum BookingStatus { pending, confirmed, active, completed, cancelled, expired }
enum PaymentStatus { pending, partial, paid, refunded, failed }

class BookingModel {
  final String id;
  final String studentId;
  final String accommodationId;
  final String landlordId;
  final DateTime startDate;
  final DateTime endDate;
  final double totalAmount;
  final double paidAmount;
  final String currency;
  final BookingStatus status;
  final PaymentStatus paymentStatus;
  final Map<String, dynamic> paymentDetails;
  final String? leaseAgreementUrl;
  final List<String> documents;
  final Map<String, dynamic> terms;
  final String? notes;
  final DateTime createdAt;
  final DateTime updatedAt;
  final DateTime? confirmedAt;
  final DateTime? cancelledAt;
  final String? cancellationReason;

  BookingModel({
    required this.id,
    required this.studentId,
    required this.accommodationId,
    required this.landlordId,
    required this.startDate,
    required this.endDate,
    required this.totalAmount,
    this.paidAmount = 0,
    this.currency = 'GHS',
    this.status = BookingStatus.pending,
    this.paymentStatus = PaymentStatus.pending,
    required this.paymentDetails,
    this.leaseAgreementUrl,
    required this.documents,
    required this.terms,
    this.notes,
    required this.createdAt,
    required this.updatedAt,
    this.confirmedAt,
    this.cancelledAt,
    this.cancellationReason,
  });

  Duration get duration => endDate.difference(startDate);
  
  int get durationInDays => duration.inDays;
  
  double get remainingAmount => totalAmount - paidAmount;
  
  bool get isFullyPaid => paidAmount >= totalAmount;
  
  bool get isActive => status == BookingStatus.active;
  
  bool get isPending => status == BookingStatus.pending;
  
  bool get isConfirmed => status == BookingStatus.confirmed;
  
  bool get isCancelled => status == BookingStatus.cancelled;
  
  bool get isExpired => status == BookingStatus.expired;
  
  bool get isCompleted => status == BookingStatus.completed;

  String get statusDisplayName {
    switch (status) {
      case BookingStatus.pending:
        return 'Pending';
      case BookingStatus.confirmed:
        return 'Confirmed';
      case BookingStatus.active:
        return 'Active';
      case BookingStatus.completed:
        return 'Completed';
      case BookingStatus.cancelled:
        return 'Cancelled';
      case BookingStatus.expired:
        return 'Expired';
    }
  }

  String get paymentStatusDisplayName {
    switch (paymentStatus) {
      case PaymentStatus.pending:
        return 'Pending';
      case PaymentStatus.partial:
        return 'Partial';
      case PaymentStatus.paid:
        return 'Paid';
      case PaymentStatus.refunded:
        return 'Refunded';
      case PaymentStatus.failed:
        return 'Failed';
    }
  }

  Map<String, dynamic> toMap() {
    return {
      'id': id,
      'studentId': studentId,
      'accommodationId': accommodationId,
      'landlordId': landlordId,
      'startDate': startDate.toIso8601String(),
      'endDate': endDate.toIso8601String(),
      'totalAmount': totalAmount,
      'paidAmount': paidAmount,
      'currency': currency,
      'status': status.name,
      'paymentStatus': paymentStatus.name,
      'paymentDetails': paymentDetails,
      'leaseAgreementUrl': leaseAgreementUrl,
      'documents': documents,
      'terms': terms,
      'notes': notes,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'confirmedAt': confirmedAt?.toIso8601String(),
      'cancelledAt': cancelledAt?.toIso8601String(),
      'cancellationReason': cancellationReason,
    };
  }

  factory BookingModel.fromMap(Map<String, dynamic> map) {
    return BookingModel(
      id: map['id'] ?? '',
      studentId: map['studentId'] ?? '',
      accommodationId: map['accommodationId'] ?? '',
      landlordId: map['landlordId'] ?? '',
      startDate: DateTime.parse(map['startDate']),
      endDate: DateTime.parse(map['endDate']),
      totalAmount: (map['totalAmount'] ?? 0.0).toDouble(),
      paidAmount: (map['paidAmount'] ?? 0.0).toDouble(),
      currency: map['currency'] ?? 'GHS',
      status: BookingStatus.values.firstWhere(
        (e) => e.name == map['status'],
        orElse: () => BookingStatus.pending,
      ),
      paymentStatus: PaymentStatus.values.firstWhere(
        (e) => e.name == map['paymentStatus'],
        orElse: () => PaymentStatus.pending,
      ),
      paymentDetails: Map<String, dynamic>.from(map['paymentDetails'] ?? {}),
      leaseAgreementUrl: map['leaseAgreementUrl'],
      documents: List<String>.from(map['documents'] ?? []),
      terms: Map<String, dynamic>.from(map['terms'] ?? {}),
      notes: map['notes'],
      createdAt: DateTime.parse(map['createdAt']),
      updatedAt: DateTime.parse(map['updatedAt']),
      confirmedAt: map['confirmedAt'] != null 
          ? DateTime.parse(map['confirmedAt']) 
          : null,
      cancelledAt: map['cancelledAt'] != null 
          ? DateTime.parse(map['cancelledAt']) 
          : null,
      cancellationReason: map['cancellationReason'],
    );
  }

  factory BookingModel.fromFirestore(DocumentSnapshot doc) {
    final data = doc.data() as Map<String, dynamic>;
    return BookingModel.fromMap({...data, 'id': doc.id});
  }

  BookingModel copyWith({
    DateTime? startDate,
    DateTime? endDate,
    double? totalAmount,
    double? paidAmount,
    BookingStatus? status,
    PaymentStatus? paymentStatus,
    Map<String, dynamic>? paymentDetails,
    String? leaseAgreementUrl,
    List<String>? documents,
    Map<String, dynamic>? terms,
    String? notes,
    DateTime? updatedAt,
    DateTime? confirmedAt,
    DateTime? cancelledAt,
    String? cancellationReason,
  }) {
    return BookingModel(
      id: id,
      studentId: studentId,
      accommodationId: accommodationId,
      landlordId: landlordId,
      startDate: startDate ?? this.startDate,
      endDate: endDate ?? this.endDate,
      totalAmount: totalAmount ?? this.totalAmount,
      paidAmount: paidAmount ?? this.paidAmount,
      currency: currency,
      status: status ?? this.status,
      paymentStatus: paymentStatus ?? this.paymentStatus,
      paymentDetails: paymentDetails ?? this.paymentDetails,
      leaseAgreementUrl: leaseAgreementUrl ?? this.leaseAgreementUrl,
      documents: documents ?? this.documents,
      terms: terms ?? this.terms,
      notes: notes ?? this.notes,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      confirmedAt: confirmedAt ?? this.confirmedAt,
      cancelledAt: cancelledAt ?? this.cancelledAt,
      cancellationReason: cancellationReason ?? this.cancellationReason,
    );
  }
}
